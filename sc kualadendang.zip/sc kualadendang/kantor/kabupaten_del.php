<?php

include('tunnel.php');

$kab_uid      = $_GET['uid'];

$sql = "DELETE FROM kabupaten where kab_uid='$kab_uid';";
//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kabupaten.php";</script>
