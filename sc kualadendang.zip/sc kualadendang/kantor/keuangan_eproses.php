<?php

include('tunnel.php');

$trans_uid      = $_POST['keu_id'];
$trans_tanggal  = $_POST['keu_tanggal'];
$trans_nomor    = $_POST['keu_nota'];
$trans_stat     = $_POST['keu_jenis'];
$trans_instansi = $_POST['keu_instansi'];
$trans_nominal  = $_POST['keu_nominal'];
$trans_ket      = $_POST['keu_keterangan'];
$trans_catatan  = $_POST['keu_catatan'];

$sql = "UPDATE transaksi set trans_nonota='$trans_nomor',trans_stat='$trans_stat', trans_instansi='$trans_instansi', trans_keterangan='$trans_ket', trans_catatan='$trans_catatan', trans_nominal='$trans_nominal' where trans_uid='$trans_uid'";

//echo $sql;


mysqli_query($koneksi,$sql);
?>
<script>window.location.href="keuangan.php";</script>
