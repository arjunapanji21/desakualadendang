<?php

include('tunnel.php');

$job_id     = $_GET['id'];
if(!isset($_GET['id'])){
    ?>
    <script>window.location.href="pengaturan.php"</script>
    <?php
}

$sql = "DELETE from pekerjaan where job_id='$job_id'";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="pengaturan.php";</script>
