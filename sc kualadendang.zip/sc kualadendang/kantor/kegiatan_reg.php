<?php

include('tunnel.php');

$keg_uid      = md5(microtime());
$keg_nama     = $_POST['keg_nama'];
$keg_tentang  = $_POST['keg_tentang'];
$keg_mulai    = $_POST['keg_mulai'];
$keg_selesai  = $_POST['keg_selesai'];

$sql = "INSERT INTO kegiatan (keg_id, keg_uid,keg_ins,keg_judul,keg_keterangan,keg_datestart,keg_dateend,keg_user)
VALUES (NULL, '$keg_uid','$userinsta','$keg_nama','$keg_tentang','$keg_mulai','$keg_selesai','$userid');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kegiatan.php";</script>
