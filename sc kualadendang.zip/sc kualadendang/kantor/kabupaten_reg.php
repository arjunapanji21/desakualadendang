<?php

include('tunnel.php');

$kab_uid      = md5(microtime());
$kab_nama     = $_POST['kab_nama'];

$sql = "INSERT INTO kabupaten (kab_id, kab_uid, kab_nama)
VALUES (NULL, '$kab_uid','$kab_nama');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kabupaten.php";</script>
