<?php

include('tunnel.php');

$anggota_uid      = md5(microtime());
$anggota_kk       = $_POST['anggota_kk'];
$anggota_nomor    = $_POST['anggota_nomor'];
$anggota_nama     = ucwords(strtolower($_POST['anggota_nama']));
$anggota_tempat   = $_POST['anggota_tempat'];
$anggota_tanggal  = $_POST['anggota_tanggal'];
$anggota_email    = $_POST['anggota_email'];
$anggota_hp       = $_POST['anggota_hp'];
$anggota_gugus    = $_POST['anggota_gugus'];
$anggota_add      = $_POST['anggota_add'];
$anggota_x        = $_POST['anggota_x'];
$anggota_y        = $_POST['anggota_y'];
$anggota_job      = $_POST['anggota_job'];
$anggota_jabatan  = "1";
$anggota_password = sha1("12345");

// New Form Update 9 Agustus 2021 //
$anggota_jk       = $_POST['anggota_jk'];//
$anggota_ektp     = $_POST['anggota_ektp'];//
$anggota_agama    = $_POST['anggota_agama'];//
$anggota_sttspend = $_POST['anggota_statuspenduduk'];

$anggota_noakta   = $_POST['anggota_nomorakta'];
$anggota_wktlhr   = $_POST['anggota_waktulahir'];
$anggota_lkslhr   = $_POST['anggota_lokasilahir'];
$anggota_jnslhr   = $_POST['anggota_jenislahir'];

$anggota_anakke   = $_POST['anggota_anakke'];
$anggota_pnlglhr  = $_POST['anggota_penolonglahir'];
$anggota_beratlhr = $_POST['anggota_beratlahir'];
$anggota_pjglahir = $_POST['anggota_panjanglahir'];

$anggota_pddkkk   = $_POST['anggota_pendidikankk'];
$anggota_pddkjln  = $_POST['anggota_pendidikanberjalan'];

$anggota_wn       = $_POST['anggota_warganegara'];
$anggota_nopaspor = $_POST['anggota_nopaspor'];
$anggota_tglpaspor= $_POST['anggota_tglpaspor'];
$anggota_nokitas  = $_POST['anggota_nokitas'];

$anggota_ktpayah  = $_POST['anggota_ktpayah'];
$anggota_noktpayah= ucwords(strtolower($_POST['anggota_namaayah']));
$anggota_ktpibu   = $_POST['anggota_ktpibu'];
$anggota_noktpibu = ucwords(strtolower($_POST['anggota_namaibu']));

$anggota_sttskawin= $_POST['anggota_statuskawin'];
$anggota_noaktakwn= $_POST['anggota_noaktanikah'];
$anggota_tglkwn   = $_POST['anggota_tglnikan'];
$anggota_noaktacri= $_POST['anggota_noaktacerai'];
$anggota_tglcri   = $_POST['anggota_tglcerai'];

$anggota_goldarah = $_POST['anggota_golongandarah'];

$anggota_ketcacat = $_POST['anggota_ketcacat'];
$anggota_ketsakit = $_POST['anggota_ketsakit'];
$anggota_akskb    = $_POST['anggota_akskb'];
$anggota_asuransi = $_POST['anggota_statusasuransi'];

$anggota_pdptbln  = $_POST['anggota_pendapatanbulan'];
$anggota_pdptmusim= $_POST['anggota_pendapatanmusim'];


$sql = "INSERT INTO anggota (ang_id, ang_uid, ang_kk,ang_nomor, ang_nama, ang_tempatlahir, ang_tanggallahir, ang_email, ang_password, ang_notelpon, ang_instansi, ang_level,ang_x,ang_y,ang_job,ang_alamat,ang_aktif,ang_sex,ang_ektp,ang_ektprek,ang_agama,ang_statuspenduduk,ang_aktano,ang_waktulahir,ang_lokasilahir,ang_jenislahir,ang_anakke,ang_penolong,ang_beratlahir,ang_panjanglahir,ang_pendidikankk,ang_pendidikannow,ang_warganegara,ang_pasporno,ang_pasportgl,ang_kitasno,ang_ayahnik,ang_ayahnama,ang_ibunik,ang_ibunama,ang_statuskawin,ang_nikahno,ang_nikahtanggal,ang_ceraino,ang_ceraitanggal,ang_goldarah,ang_cacatpermanen,ang_sakitmenahun,ang_akseptorkb,ang_asuransi,ang_pendapatanbulan,ang_pendapatmusim)
VALUES (NULL, '$anggota_uid','$anggota_kk','$anggota_nomor','$anggota_nama','$anggota_tempat','$anggota_tanggal','$anggota_email','$anggota_password','$anggota_hp','$anggota_gugus','$anggota_jabatan','$anggota_x','$anggota_y','$anggota_job','$anggota_add','1','$anggota_jk','$anggota_nomor','$anggota_ektp','$anggota_agama','$anggota_sttspend','$anggota_noakta','$anggota_wktlhr','$anggota_lkslhr','$anggota_jnslhr','$anggota_anakke','$anggota_pnlglhr','$anggota_beratlhr','$anggota_pjglahir','$anggota_pddkkk','$anggota_pddkjln','$anggota_wn','$anggota_nopaspor','$anggota_tglpaspor','$anggota_nokitas','$anggota_ktpayah','$anggota_noktpayah','$anggota_ktpibu','$anggota_noktpibu','$anggota_sttskawin','$anggota_noaktakwn','$anggota_tglkwn','$anggota_noaktacri','$anggota_tglcri','$anggota_goldarah','$anggota_ketcacat','$anggota_ketsakit','$anggota_akskb','$anggota_asuransi','$anggota_pdptbln','$anggota_pdptmusim');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="anggota.php";</script>
