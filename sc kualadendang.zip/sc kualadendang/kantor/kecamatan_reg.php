<?php

include('tunnel.php');

$kec_uid      = md5(microtime());
$kec_nama     = $_POST['kec_nama'];
$kec_kabkot   = $_POST['kec_kabkot'];

$sql = "INSERT INTO kecamatan (kec_id, kec_uid, kec_nama, kab_id)
VALUES (NULL, '$kec_uid','$kec_nama','$kec_kabkot');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kecamatan.php";</script>
