<?php include('tunnel.php');
$dusun  = $_POST['data_dusun'];
$rt     = $_POST['data_rt'];
$rw     = $_POST['data_rw'];

if($dusun=="Semua Dusun"){ $sql1=""; }else{ $sql1="and kk_dusun='".$dusun."'";  }
if($rt=="Semua RT"){ $sql2=""; }else{ $sql2="and kk_rt='".$rt."'";  }
if($rw=="Semua RW"){ $sql3=""; }else{ $sql3="and kk_rw='".$rw."'";  }

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan Data Keluarga ".md5(microtime()).".xls");
?>
    <table class="table table-hover table-outline table-vcenter card-table">
        <thead>
        <tr>
            <th colspan="7"><center>DATA PENDUDUK</center></th>
        </tr>
        <tr>
            <th>NO. KK</th>
            <th>NIK</th>
            <th>NAMA</th>
            <th>STATUS HUBUNGAN</th>
            <th>TTL</th>
            <th>PEKERJAAN</th>
            <th>AGAMA</th>
            <th>JENKEL</th>
            <th>DUSUN</th>
            <th>RT</th>
            <th>RW</th>
            <th>PENDAPATAN BULANAN</th>
            <th>PENDAPATAN MUSIMAN</th>
            <th class="text-center"><i class="icon-settings"></i></th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sql="select a.ang_kk,a.ang_nomor,a.ang_nama,a.ang_instansi,a.ang_sex,a.ang_tempatlahir,a.ang_tanggallahir,a.ang_job,a.ang_agama,a.ang_pendapatanbulan,a.ang_pendapatmusim,b.kk_dusun,b.kk_rt,b.kk_rw from anggota a,data_kk b where a.ang_kk=b.kk_nomor $sql1 $sql2 $sql3";
        $query=mysqli_query($koneksi,$sql);
        while($rsx=mysqli_fetch_array($query)){

            $ins= $rsx['ang_instansi'];
            $job= $rsx['ang_job'];
            $agm= $rsx['ang_agama'];
            $sex= $rsx['ang_sex'];
            $ang_tmp = $rsx['ang_tempatlahir'];
            $ang_tgl = dtotgl($rsx['ang_tanggallahir']);

            $rs = mysqli_fetch_array(mysqli_query($koneksi,"select * from status where stat_id ='$ins'"));
            if(isset($rs['stat_nama'])){ $status_hubungan = $rs['stat_nama']; }else{ $status_hubungan="-"; }

            $rsj = mysqli_fetch_array(mysqli_query($koneksi,"select * from pekerjaan where job_id ='$job'"));
            if(isset($rsj['job_nama'])){ $pekerjaan = $rsj['job_nama']; }else{ $pekerjaan="-"; }

            $rsa = mysqli_fetch_array(mysqli_query($koneksi,"select * from statusagama where stat_id ='$agm'"));
            if(isset($rsa['stat_nama'])){ $agama = $rsa['stat_nama']; }else{ $agama="-"; }

            $rss = mysqli_fetch_array(mysqli_query($koneksi,"select * from statuskelamin where stat_id ='$sex'"));
            if(isset($rss['stat_nama'])){ $sex = $rss['stat_nama']; }else{ $sex="-"; }
        ?>
        <tr>
            <td>'<?php echo $rsx['ang_kk']; ?></td>
            <td>'<?php echo $rsx['ang_nomor']; ?></td>
            <td><?php echo $rsx['ang_nama']; ?></td>
            <td><?php echo $status_hubungan; ?></td>
            <td><?php echo $ang_tmp; ?>, <?php echo $ang_tgl; ?></td>
            <td><?php echo $pekerjaan; ?></td>
            <td><?php echo $agama; ?></td>
            <td><?php echo $sex; ?></td>
            <td><?php echo $rsx['kk_dusun']; ?></td>
            <td><?php echo $rsx['kk_rt']; ?></td>
            <td><?php echo $rsx['kk_rw']; ?></td>
            <td><?php echo $rsx['ang_pendapatanbulan']; ?></td>
            <td><?php echo $rsx['ang_pendapatmusim']; ?></td>
        </tr>
        <?php } ?>
        </tbody>
    </table>