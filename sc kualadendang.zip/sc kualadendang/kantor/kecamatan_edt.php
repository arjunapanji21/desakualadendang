<?php

include('tunnel.php');

$kec_uid      = $_POST['kec_uid'];
$kec_nama     = $_POST['kec_nama'];
$kec_kabkot   = $_POST['kec_kabkot'];

$sql = "UPDATE kecamatan set kec_nama='$kec_nama',kab_id='$kec_kabkot' WHERE kec_uid='$kec_uid'";

//echo $sql;

mysqli_query($koneksi,$sql);

?>
<script>window.location.href="kecamatan.php";</script>
