<?php include('tunnel.php'); ?>
<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Language" content="en" />
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <link rel="icon" href="./assets/images/logo/pramuka.png" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/images/logo/pramuka.png" />
    <script src="./assets/wordpad/nicEdit.js" type="text/javascript"></script>
    <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>	
    <!-- Generated: 2018-04-16 09:29:05 +0200 -->
    <title>Kegiatan Form Tambah- SiPETA</title>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">
    <style>
      @import url(https://fonts.googleapis.com/css?family=Roboto);

      body {
        font-family: Roboto, sans-serif;
      }

      #chart {
        max-width: 650px;
        margin: 35px auto;
      }
      #chart2 {
        max-width: 650px;
        margin: 35px auto;
      }

    </style>
    <script src="./assets/js/require.min.js"></script>
    <script>
      requirejs.config({
          baseUrl: '.'
      });
    </script>
    <!-- Dashboard Core -->
    
    <link href="./assets/css/dashboard.css" rel="stylesheet" />
    <script src="./assets/js/dashboard.js"></script>
    <!-- c3.js Charts Plugin -->
    <link href="./assets/plugins/charts-c3/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/charts-c3/plugin.js"></script>
    <!-- Google Maps Plugin -->
    <link href="./assets/plugins/maps-google/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/maps-google/plugin.js"></script>
    <!-- Input Mask Plugin -->
    <script src="./assets/plugins/input-mask/plugin.js"></script>

    <link href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css" rel="stylesheet" />
  </head>
  <body class="">
    <div class="page">
      <div class="page-main">
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="./index.php">
                <img src="./assets/images/logo/pramuka.png" class="header-brand-img" alt="tabler logo"> SiPETA
              </a>
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(./demo/faces/female/25.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo $user; ?></span>
                      <small class="text-muted d-block mt-1"><?php echo $usergugus; ?></small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <?php include('menu_profile.php'); ?>
                  </div>
                </div>
              </div>
              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3 ml-auto">
                <form class="input-icon my-3 my-lg-0">
                  <input type="search" class="form-control header-search" placeholder="Search&hellip;" tabindex="1">
                  <div class="input-icon-addon">
                    <i class="fe fe-search"></i>
                  </div>
                </form>
              </div>
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="./index.php" class="nav-link"><i class="fe fe-home"></i> Home</a>
                  </li>
                  <li class="nav-item">
                    <a href="./info_desa.php" class="nav-link"><i class="fe fe-award"></i> Info Desa</a>
                  </li>
                  <li class="nav-item">
                    <a href="./anggota.php" class="nav-link"><i class="fe fe-users"></i> Penduduk</a>
                  </li>
                  <li class="nav-item">
                    <a href="./statistik.php" class="nav-link active"><i class="fe fe-users"></i> Statistik</a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown"><i class="fe fe-box"></i> Sekretariat</a>
                    <div class="dropdown-menu dropdown-menu-arrow">
                      <a href="surat.php" class="dropdown-item ">Layanan Surat</a>
                      <a href="keuangan.php" class="dropdown-item ">Keuangan</a>
                      <a href="#" class="dropdown-item ">Pertanahan</a>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link"><i class="fe fe-users"></i> Analisis</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link"><i class="fe fe-settings"></i> Pengaturan</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link"><i class="fe fe-users"></i> Admin Web</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title">
              </h1>
            </div>
            <div class="row row-cards row-deck">
              <div class="col-md-12 col-lg-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Statistik Desa</h3>
                </div>
                <?php
                $laki2 = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_sex='L'"));
                $perempuan= mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_sex='P'"));
                $nojenkel = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota"));
                $nojenkel = $nojenkel - $laki2 - $perempuan;
                $bekerja = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_job!='11'"));
                $tbekerja= mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_job='11'"));
                ?>
                <div class="card-table row">
                  <div class="col-4">
                    <center><h2>Data Jenis Kelamin</h2></center>
                    <div id="chart"></div>
                  </div>
                  <div class="col-2">
                    &nbsp;l
                  </div>
                  <div class="col-4">
                    <center><h2>Data Pekerjaan</h2></center>
                    <div id="chart2"></div>
                  </div>
                </div>

               

              </div>
            </div>

             <!-- Untuk charts -->
            <div class="row">
              <div class="col-12">
                
              </div>
            </div>


            <!-- bukan charts -->
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
              <div class="row align-items-center">
                <div class="col-auto">
                  <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="./docs/index.php">Documentation</a></li>
                    <li class="list-inline-item"><a href="./faq.html">FAQ</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright © <?php echo date('Y'); ?> <a href=".">SiPeta</a>. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
      <script>
        var options = {
        chart: {
          type: 'bar'
        },
        series: [{
          name: 'Jumlah',
          data: [<?php echo $laki2; ?>,<?php echo $perempuan; ?>,<?php echo $nojenkel; ?>]
        }],
        xaxis: {
          categories: ['Pria','Wanita','Tidak DiIdentifikasi']
        }
      }

      var chart = new ApexCharts(document.querySelector("#chart"), options);

      chart.render();
      </script>
      <script>
        var options = {
        chart: {
          type: 'bar'
        },
        series: [{
          name: 'Jumlah',
          data: [<?php echo $bekerja; ?>,<?php echo $tbekerja; ?>]
        }],
        xaxis: {
          categories: ['Bekerja','Tidak Bekerja']
        }
      }

      var chart = new ApexCharts(document.querySelector("#chart2"), options);

      chart.render();
      </script>
    </div>
  </body>
</html>
