<?php

include('tunnel.php');

$kab_uid      = $_POST['kab_uid'];
$kab_nama     = $_POST['kab_nama'];

$sql = "UPDATE kabupaten set kab_nama='$kab_nama' where kab_uid='$kab_uid'";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kabupaten.php";</script>
