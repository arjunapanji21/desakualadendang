<?php include('tunnel.php'); 

$padi_id = base64_decode($_POST['ternak_id']);
$padi_jn = $_POST['ikan_luas'];
$padi_vr = $_POST['ikan_jenis'];
$padi_sb = $_POST['ikan_pop'];
$padi_ls = $_POST['ikan_panen'];
$padi_pr = $_POST['ikan_olah'];
$padi_pl = $_POST['ikan_hasil'];
$padi_st = $_POST['ikan_milik'];


$sql="INSERT INTO `data_ikan`(`ikan_autoid`, `kk_nomor`, `ikan_luas`, `ikan_jenis`, `ikan_populasi`, `ikan_panen`, `ikan_olah`, `ikan_hasil`, `ikan_milik`) 
VALUES (NULL,'$padi_id','$padi_jn','$padi_vr','$padi_sb','$padi_ls','$padi_pr','$padi_pl','$padi_st')";

mysqli_query($koneksi,$sql);

?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo base64_encode($padi_id); ?>"</script>