<?php

include('tunnel.php');

$kwartir_uid      = $_GET['uid'];

$sql = "DELETE FROM instansi where ins_uid='$kwartir_uid';";
//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="instansi.php";</script>
