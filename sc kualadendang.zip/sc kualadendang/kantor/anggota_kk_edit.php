<?php include('tunnel.php'); $kkid=base64_decode($_GET['kkid']);?>
<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Language" content="en" />
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <link rel="icon" href="./assets/images/logo/pramuka.png" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/images/logo/pramuka.png" />
    <!-- Generated: 2018-04-16 09:29:05 +0200 -->
    <title>Penduduk - SiPETA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">
    <script src="./assets/js/require.min.js"></script>
    <script>
      requirejs.config({
          baseUrl: '.'
      });
    </script>
    <!-- Dashboard Core -->
    <link href="./assets/css/dashboard.css" rel="stylesheet" />
    <script src="./assets/js/dashboard.js"></script>
    <!-- c3.js Charts Plugin -->
    <link href="./assets/plugins/charts-c3/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/charts-c3/plugin.js"></script>
    <!-- Google Maps Plugin -->
    <link href="./assets/plugins/maps-google/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/maps-google/plugin.js"></script>
    <!-- Input Mask Plugin -->
    <script src="./assets/plugins/input-mask/plugin.js"></script>
    <script>
      require(['datatables'], function() {
          $(document).ready(function () {
              $('#table').DataTable({
              });
          });
      });
    </script>
    <link href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css" rel="stylesheet" />
  </head>
  <body class="">
    <div class="page">
      <div class="page-main">
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="./index.php">
                <img src="./assets/images/logo/pramuka.png" class="header-brand-img" alt="tabler logo"> SiPETA
              </a>
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(./demo/faces/female/25.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo $user; ?></span>
                      <small class="text-muted d-block mt-1"><?php echo $usergugus; ?></small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <?php include('menu_profile.php'); ?>
                  </div>
                </div>
              </div>
              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3 ml-auto">
              </div>
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="./index.php" class="nav-link"><i class="fe fe-home"></i> Home</a>
                  </li>
                  <li class="nav-item">
                    <a href="./info_desa.php" class="nav-link"><i class="fe fe-award"></i> Info Desa</a>
                  </li>
                  <li class="nav-item">
                    <a href="./statistik.php" class="nav-link active"><i class="fe fe-users"></i> Penduduk</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Statistik</a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown"><i class="fe fe-box"></i> Sekretariat</a>
                    <div class="dropdown-menu dropdown-menu-arrow">
                      <a href="surat.php" class="dropdown-item ">Layanan Surat</a>
                      <a href="keuangan.php" class="dropdown-item ">Keuangan</a>
                      <a href="#" class="dropdown-item ">Pertanahan</a>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Analisis</a>
                  </li>
                  <li class="nav-item">
                    <a href="pengaturan.php" class="nav-link"><i class="fe fe-settings"></i> Pengaturan</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Admin Web</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title">
                KARTU KELUARGA NOMOR : <?php echo $kkid; ?>
              </h1>
            </div>
            <div class="row row-cards">
              <div class="col-sm-12 col-lg-12">
              </div>
            </div>
            <div class="row row-cards row-deck">
            
              <div class="col-12">
                <div class="card">
                  <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter card-table">
                      <thead>
                        <tr>
                          <th>NO. PENDUDUK</th>
                          <th>NAMA PENDUDUK</th>
                          <th>TEMPAT/TANGGAL LAHIR</th>
                          <th>JENIS KELAMIN</th>
                          <th>STATUS</th>
                          <th class="text-center"><i class="icon-settings"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        //Cek data KK, Keluarga, Pengeluaran, DLL
                        $cekdata = mysqli_num_rows(mysqli_query($koneksi,"select * from data_kk where kk_nomor='$kkid'"));
                        if($cekdata>0){}else{ 
                            
                            mysqli_query($koneksi,"INSERT INTO `data_kk`(`kk_autoid`, `kk_nomor`, `kk_dusun`, `kk_rt`, `kk_rw`, `kk_nohp`, `kk_email`, `kk_lokasi`, `kk_latitude`, `kk_longitude`) VALUES (NULL,'$kkid','','','','','','','','')"); 
                            mysqli_query($koneksi,"INSERT INTO data_keluarga(kel_autoid,kk_nomor,kel_listrik,kel_daya,kel_masak,kel_air,kel_mck,kel_bangun,kel_konstruksi,kel_rumah) VALUES (NULL,'$kkid','','','','','','','','')"); 
                            mysqli_query($koneksi,"INSERT INTO `data_pengeluaran`(`peng_autoid`,`kk_nomor`, `peng_bel1`, `peng_bel2`, `peng_bel3`, `peng_bel4`, `peng_bel5`, `peng_bel6`, `peng_ener1`, `peng_ener2`, `peng_ener3`, `peng_ener4`, `peng_usaha1`, `peng_usaha2`, `peng_usaha3`, `peng_usaha4`, `peng_usaha5`, `peng_usaha6`, `peng_pend1`, `peng_pend2`, `peng_pend3`, `peng_kes1`, `peng_kes2`, `peng_kes3`, `peng_kom1`, `peng_sos1`, `peng_sos2`, `peng_sos3`, `peng_lain1`, `peng_lain2`) VALUES (NULL,'$kkid','','','','','','','','','','','','','','','','','','','','','','','','','','','','')");
                            mysqli_query($koneksi,"INSERT INTO `data_aset`(`aset_autoid`, `kk_nomor`, `aset_1`, `aset_2`, `aset_3`, `aset_4`, `aset_5`, `aset_6`, `aset_7`, `aset_8`, `aset_9`, `aset_10`) VALUES (NULL,'$kkid','','','','','','','','','','')");
                            ?><script>window.location.href="anggota_kk_edit.php?kkid=<?php echo base64_encode($kkid); ?>";</script><?php
                        }
                        
                        $jumlah = 0;
                        $sql="select * from anggota where ang_kk='$kkid'";
                        $query=mysqli_query($koneksi,$sql);
                        while($rs=mysqli_fetch_array($query)){

                          $id= $rs['12'];
                          $sx= $rs['5'];
                          
                          if($sx=="1"){ $sex = "Pria"; }else{ $sex="Wanita"; }

                          $rsjabatan = mysqli_fetch_array(mysqli_query($koneksi,"select * from status where stat_id ='$id'"));
                          $jabatan = $rsjabatan['stat_nama'];
                        ?>
                        <tr>
                          <td><?php echo $rs['3']; ?></td>
                          <td><?php echo $rs['4']; ?></td>
                          <td><?php echo $rs['6']; ?>, <?php echo dtostr($rs['7']); ?></td>
                          <td><?php echo ($sex); ?></td>
                          <td><?php echo $jabatan; ?></td>
                          <td class="text-center">
                              <a href="anggota_kk_edit.php?kkid=<?php echo base64_encode($rs['2']) ?>" class="icon"><i class="fe fe-edit"></i></a>
                          </td>
                        </tr>
                        <?php $jumlah+=1; } ?>
                        <tr>
                          <td colspan="6">Jumlah Jiwa <?php echo $jumlah; ?> Orang</td>
                        </tr>
                      </tbody>
                    </table>
                    </div>
                </div>
              </div>
              <!-- Data KK Awal -->
              <?php
              $rs1 = mysqli_fetch_array(mysqli_query($koneksi,"select * from data_kk where kk_nomor='$kkid'"));
              $encid = base64_encode($kkid);
              ?>
              
              <div class="col-12">
                  <form method="POST" action="anggota_kk_update.php?zass=<?php echo $encid; ?>">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><strong>Data Kartu Keluarga</strong></td>
                            </tr>
                            <tr>
                              <td colspan="3">Dusun</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="Dusun" name="kk_dusun" id="kk_dusun" value="<?php echo $rs1['kk_dusun']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">RT</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="RT" name="kk_rt" id="kk_rt" value="<?php echo $rs1['kk_rt']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">RW</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="RW" name="kk_rw" id="kk_rw" value="<?php echo $rs1['kk_rw']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">No. HP</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="No. Handphone" name="kk_hp" id="kk_hp" value="<?php echo $rs1['kk_nohp']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">Email</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="Alamat Email" name="kk_email" id="kk_email" value="<?php echo $rs1['kk_email']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">Lokasi</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="Lokasi" name="kk_lokas" id="kk_lokas" value="<?php echo $rs1['kk_lokasi']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">Latitude</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="Latitude" name="kk_lat" id="kk_lat" value="<?php echo $rs1['kk_latitude']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">Longitude</td>
                              <td colspan="3"><input type="text" class="form-control" placeholder="Longitude" name="kk_lon" id="kk_lon" value="<?php echo $rs1['kk_longitude']; ?>"></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data KK Bawah -->
              <!-- Data Keluarga Awal -->
              <?php
              $rs2 = mysqli_fetch_array(mysqli_query($koneksi,"select * from data_keluarga where kk_nomor='$kkid'"));
              $listrik = $rs2['kel_listrik'];
              $daya    = $rs2['kel_daya'];
              $masak   = $rs2['kel_masak'];
              $air     = $rs2['kel_air'];
              $mck     = $rs2['kel_mck'];
              $bangunan= $rs2['kel_bangun'];
              $kons    = $rs2['kel_konstruksi'];
              $rumah   = $rs2['kel_rumah'];
              ?>
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><strong>Data Keluarga</strong></td>
                            </tr>
                            <tr>
                              <td colspan="3">Sumber Listrik</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_listrik" id="kel_listrik">
                                      <option value="0" <?php if($listrik=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($listrik=="1"){ echo "selected"; } ?>>PLN</option>
                                      <option value="2" <?php if($listrik=="2"){ echo "selected"; } ?>>Bukan PLN</option>
                                      <option value="3" <?php if($listrik=="3"){ echo "selected"; } ?>>Tidak Ada</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Jumlah Daya</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_daya" id="kel_daya">
                                      <option value="0" <?php if($daya=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($daya=="1"){ echo "selected"; } ?>>< 450 Watt</option>
                                      <option value="2" <?php if($daya=="2"){ echo "selected"; } ?>>450 - 900 Watt</option>
                                      <option value="3" <?php if($daya=="3"){ echo "selected"; } ?>>> 900 Watt</option>
                                      <option value="4" <?php if($daya=="4"){ echo "selected"; } ?>>Tidak Ada</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Energi Masak</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_masak" id="kel_masak">
                                      <option value="0" <?php if($masak=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($masak=="1"){ echo "selected"; } ?>>Listrik</option>
                                      <option value="2" <?php if($masak=="2"){ echo "selected"; } ?>>Gas Tabung</option>
                                      <option value="3" <?php if($masak=="3"){ echo "selected"; } ?>>Biogas</option>
                                      <option value="4" <?php if($masak=="4"){ echo "selected"; } ?>>Kompor Minyak</option>
                                      <option value="5" <?php if($masak=="5"){ echo "selected"; } ?>>Kayu Bakar</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Sumber Air Bersih</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_air" id="kel_air">
                                      <option value="0" <?php if($air=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($air=="1"){ echo "selected"; } ?>>PDAM</option>
                                      <option value="2" <?php if($air=="2"){ echo "selected"; } ?>>Sumur Bor</option>
                                      <option value="3" <?php if($air=="3"){ echo "selected"; } ?>>Sumur Gali</option>
                                      <option value="4" <?php if($air=="4"){ echo "selected"; } ?>>Air Galon</option>
                                      <option value="5" <?php if($air=="5"){ echo "selected"; } ?>>Air Hujan</option>
                                      <option value="6" <?php if($air=="6"){ echo "selected"; } ?>>Sungai</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">M.C.K</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_mck" id="kel_mck">
                                      <option value="0" <?php if($mck=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($mck=="1"){ echo "selected"; } ?>>Dalam Rumah</option>
                                      <option value="2" <?php if($mck=="2"){ echo "selected"; } ?>>Luar Rumah</option>
                                      <option value="3" <?php if($mck=="3"){ echo "selected"; } ?>>Tidak Ada</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Jenis Bangunan</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_bangunan" id="kel_bangunan">
                                      <option value="0" <?php if($bangunan=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($bangunan=="1"){ echo "selected"; } ?>>Rumah Panggung</option>
                                      <option value="2" <?php if($bangunan=="2"){ echo "selected"; } ?>>Rumah Bukan Panggung</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Jenis Konstruksi</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_kons" id="kel_kons">
                                      <option value="0" <?php if($kons=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($kons=="1"){ echo "selected"; } ?>>Permanen</option>
                                      <option value="2" <?php if($kons=="2"){ echo "selected"; } ?>>Semi Permanen</option>
                                      <option value="3" <?php if($kons=="3"){ echo "selected"; } ?>>Darurat</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Kepemilikan Rumah</td>
                              <td colspan="3">
                                  <select class="form-control" name="kel_rumah" id="kel_rumah">
                                      <option value="0" <?php if($rumah=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($rumah=="1"){ echo "selected"; } ?>>Milik Sendiri</option>
                                      <option value="2" <?php if($rumah=="2"){ echo "selected"; } ?>>Milik Orang Tua/ Mertua</option>
                                      <option value="3" <?php if($rumah=="3"){ echo "selected"; } ?>>Milik Keluarga/ Numpang</option></option>
                                      <option value="4" <?php if($rumah=="4"){ echo "selected"; } ?>>Rumah Dinas</option>
                                  </select>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Keluarga Bawah -->
              <!-- Data Pengeluaran Awal -->
              <?php
              $rs3 = mysqli_fetch_array(mysqli_query($koneksi,"select * from data_pengeluaran where kk_nomor='$kkid'"));
              ?>
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><strong>Data Pengeluaran</strong></td>
                            </tr>
                            <tr>
                              <td colspan="3"><strong>1. Belanja Pangan</strong></td>
                              <td colspan="3"><strong>4. Belanja Pendidikan</strong></td>
                            </tr>
                            <tr>
                              <td>a. Beras</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Beras" name="pen_beras" id="pen_beras" value="<?php echo $rs3['peng_bel1']; ?>"></td>
                              <td>a. Spp/Iuran Sekolah</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Spp/ Iuran/ Sekolah" name="pen_spp" id="pen_spp" value="<?php echo $rs3['peng_pend1']; ?>"></td>
                            </tr>
                            <tr>
                              <td>b. Lauk Pauk</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Lauk Pauk" name="pen_lauk" id="pen_lauk" value="<?php echo $rs3['peng_bel2']; ?>"></td>
                              <td>b. Transportasi /Kost /Jajan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Transportasi /Kost /Jajan" name="pen_kost" id="pen_kost" value="<?php echo $rs3['peng_pend2']; ?>"></td>
                            </tr>
                            <tr>
                              <td>c. Aneka Sayur</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Aneka Sayur" name="pen_sayur" id="pen_sayur" value="<?php echo $rs3['peng_bel3']; ?>"></td>
                              <td>c. Perlengkapan Sekolah</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Perlengkapan Sekolah" name="pen_sekolah" id="pen_sekolah" value="<?php echo $rs3['peng_pend3']; ?>"></td>
                            </tr>
                            <tr>
                              <td>d. Bumbu Masak</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Bumbu Masak" name="pen_bumbu" id="pen_bumbu" value="<?php echo $rs3['peng_bel4']; ?>"></td>
                              <td colspan="3"><strong>5. Belanja Kesehatan</strong></td>
                            </tr>
                            <tr>
                              <td>e. Rokok</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Rokok" name="pen_rokok" id="pen_rokok" value="<?php echo $rs3['peng_bel5']; ?>"></td>
                              <td>a. Periksa Kesehatan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Periksa Kesehatan" name="pen_sehat" id="pen_sehat" value="<?php echo $rs3['peng_kes1']; ?>"></td>
                            </tr>
                            <tr>
                              <td>f. Biaya Air Bersih</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Biaya Air Bersih" name="pen_air" id="pen_air" value="<?php echo $rs3['peng_bel6']; ?>"></td>
                              <td>b. Obat</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Obat" name="pen_obat" id="pen_obat" value="<?php echo $rs3['peng_kes2']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3"><strong>2. Belanja Energi</strong></td>
                              <td>c. Sanitary</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Sanitary" name="pen_energi" id="pen_energi" value="<?php echo $rs3['peng_kes3']; ?>"></td>
                            </tr>
                            <tr>
                              <td>a. Minyak Tanah</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Minyak Tanah" name="pen_minyak" id="pen_minyak" value="<?php echo $rs3['peng_ener1']; ?>"></td>
                              <td colspan="3"><strong>6. Belanja Komunikasi</strong></td>
                            </tr>
                            <tr>
                              <td>b. Gas</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Gas" name="pen_gas" id="pen_gas" value="<?php echo $rs3['peng_ener2']; ?>"></td>
                              <td>a. Pulsa HP</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Pulsa HP" name="pen_pulsa" id="pen_pulsa" value="<?php echo $rs3['peng_kom1']; ?>"></td>
                            </tr>
                            <tr>
                              <td>c. Biaya Listrik</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Biaya Listrik" name="pen_listrik" id="pen_listrik" value="<?php echo $rs3['peng_ener3']; ?>"></td>
                              <td colspan="3"><strong>7. Belanja Sosial</strong></td>
                            </tr>
                            <tr>
                              <td>d. BBM</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="BBM" name="pen_bbm" id="pen_bbm" value="<?php echo $rs3['peng_ener4']; ?>"></td>
                              <td>a. Iuran Kampung</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Iuran Kampung" name="pen_iuran" id="pen_iuran" value="<?php echo $rs3['peng_sos1']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3"><strong>3. Belanja Usaha</strong></td>
                              <td>b. Sumbangan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Sumbangan" name="pen_sumbangan" id="pen_sumbangan" value="<?php echo $rs3['peng_sos2']; ?>"></td>
                            </tr>
                            <tr>
                              <td>a. Pupuk</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Pupuk" name="pen_pupuk" id="pen_pupuk" value="<?php echo $rs3['peng_usaha1']; ?>"></td>
                              <td>c. Arisan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Arisan" name="pen_arisan" id="pen_arisan" value="<?php echo $rs3['peng_sos3']; ?>"></td>
                            </tr>
                            <tr>
                              <td>b. Racun</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Racun" name="pen_racun" id="pen_racun" value="<?php echo $rs3['peng_usaha2']; ?>"></td>
                              <td colspan="3"><strong>8. Belanja Lain - Lain</strong></td>
                            </tr>
                            <tr>
                              <td>c. Benih</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Benih" name="pen_benih" id="pen_benih" value="<?php echo $rs3['peng_usaha3']; ?>"></td>
                              <td>a. Hiburan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Hiburan" name="pen_hiburan" id="pen_hiburan" value="<?php echo $rs3['peng_lain1']; ?>"></td>
                            </tr>
                            <tr>
                              <td>d. Upah Buruh</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Upah Buruh" name="pen_upah" id="pen_upah" value="<?php echo $rs3['peng_usaha4']; ?>"></td>
                              <td>b. Tabungan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Tabungan" name="pen_tabungan" id="pen_tabungan" value="<?php echo $rs3['peng_lain2']; ?>"></td>
                            </tr>
                            <tr>
                              <td>e. Sewa Lahan</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Sewa Lahan" name="pen_sewa" id="pen_sewa" value="<?php echo $rs3['peng_usaha5']; ?>"></td>
                              <td colspan="3">&nbsp;</td>
                            </tr>
                            <tr>
                              <td>f. Transportasi</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Transportasi" name="pen_transport" id="pen_transport" value="<?php echo $rs3['peng_usaha6']; ?>"></td>
                              <td colspan="3">&nbsp;</td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Pengeluaran Bawah -->
              <!-- Data Pengeluaran Awal -->
              <?php
              $rs5 = mysqli_fetch_array(mysqli_query($koneksi,"select * from data_aset where kk_nomor='$kkid'"));
              ?>
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><strong>Data Aset Keluarga</strong></td>
                            </tr>
                            <tr>
                              <td colspan="3"><strong>Lahan</strong></td>
                              <td colspan="3"><strong>Mesin & Alat Kerja</strong></td>
                            </tr>
                            <tr>
                              <td>Lahan Usaha (Ha)</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Lahan Usaha" name="aset_lahan" id="aset_lahan" value="<?php echo $rs5['aset_1']; ?>"></td>
                              <td>Traktor</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Traktor" name="aset_traktor" id="aset_traktor" value="<?php echo $rs5['aset_2']; ?>"></td>
                            </tr>
                            <tr>
                              <td>Lahan Rumah (m2)</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Lahan Rumah" name="aset_rumah" id="aset_rumah" value="<?php echo $rs5['aset_3']; ?>"></td>
                              <td>Mesin Giling Padi</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Mesin Giling Padi" name="aset_mesin" id="aset_mesin" value="<?php echo $rs5['aset_4']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3">&nbsp;</td>
                              <td>Mesin Jahit</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Meisn Jahit" name="aset_jahit" id="aset_jahit" value="<?php echo $rs5['aset_5']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3"><strong>Bangunan</strong></td>
                              <td colspan="3"><strong>Kendaraan</strong></td>
                            </tr>
                            <tr>
                              <td>Bangunan Rumah (m2)</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Bangunan Rumah" name="aset_bangun" id="aset_bangun" value="<?php echo $rs5['aset_6']; ?>"></td>
                              <td>Motor</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Motor" name="aset_motor" id="aset_motor" value="<?php echo $rs5['aset_7']; ?>"></td>
                            </tr>
                            <tr>
                              <td>Bangunan Usaha (m2)</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Bangunan Usaha" name="aset_usaha" id="aset_usaha" value="<?php echo $rs5['aset_8']; ?>"></td>
                              <td>Mobil</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Mobil" name="aset_mobil" id="aset_mobil" value="<?php echo $rs5['aset_9']; ?>"></td>
                            </tr>
                            <tr>
                              <td colspan="3"><strong>&nbsp;</strong></td>
                              <td>Lainnya</td>
                              <td colspan="2"><input type="text" class="form-control" placeholder="Lainnya" name="aset_lain" id="aset_lain" value="<?php echo $rs5['aset_10']; ?>"></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Pengeluaran Bawah -->
              <!-- Area Submit -->
              <?php
              $rs1 = mysqli_fetch_array(mysqli_query($koneksi,"select * from data_kk where kk_nomor='$kkid'"));
              ?>
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><input type="submit" class="btn btn-success" value="UPDATE DATA">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="anggota_kk.php" style="text-decoration:none;">Kembali</a></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              </form>
              <!-- Area Submit -->
              
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6">DATA FOTO RUMAH</td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Foto Rumah -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-vcenter card-table" border="1">
                          <thead>
                              <td colspan="11">
                                DATA FOTO RUMAH&nbsp;&nbsp;
                                <a href="upload/index.php?kkid=<?php echo base64_encode($kkid); ?>" class="btn btn-sm btn-primary" target="_blank">TAMBAH FOTO</a>
                            </td>
                          </thead>    
                          <thead>
                              <th>Nomor</th>
                              <th>Nama Foto</th>
                              <th>&nbsp;</th>
                            </th>
                          </thead>
                          <tbody>
                              <?php
                              $i=1;
                              $kkuid = base64_encode($kkid);
                              $sql = mysqli_query($koneksi,"select * from data_files where files_kkid='$kkuid' order by files_dates ASC");
                              while($rs=mysqli_fetch_array($sql)){
                                  
                              ?>
                              <tr>
                                  <td><?php echo $i; ?></td>
                                  <td><?php echo $rs['files_nama']; ?></td>
                                  <td>
                                      <a href="upload/files/<?php echo $rs['files_lokasi']; ?>" style="text-decoration:none;" target="_blank">Lihat</a>&nbsp;&nbsp;
                                      <a href="anggota_kk_files_hapus.php?id=<?php echo base64_encode($rs['files_uid']); ?>&uiz=<?php echo base64_encode($kkid); ?>" style="text-decoration:none;" onclick="return confirm('Yakin anda ingin menghapus data ini ? ');">Hapus</a>
                                  </td>
                              </tr>
                              <?php $i+=1; } ?>
                              <tr>
                                  <td colspan="11"></td>
                              </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Foto Rumah -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6">DATA PERTANIAN, PERTENAKAN, PERIKANAN</td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Padi -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-vcenter card-table" border="1">
                          <thead>
                              <td colspan="11">
                                DATA PADI&nbsp;&nbsp;
                                <a href="anggota_kk_padi_tambah.php?kkid=<?php echo base64_encode($kkid); ?>" class="btn btn-sm btn-primary">TAMBAH DATA</a>
                            </td>
                          </thead>    
                          <thead>
                              <th>Jenis Padi</th>
                              <th>Varietas</th>
                              <th>Sumber Benih</th>
                              <th>Luas Lahan<br>(ha)</th>
                              <th>Produktivitas<br>(ton/Ha)</th>
                              <th>Pola Tanam</th>
                              <th>Sistem Budidaya</th>
                              <th>Pengairan</th>
                              <th>Pemanfaatan Hasil</th>
                              <th>Kepemilikan Lahan</th>
                              <th>&nbsp;</th>
                            </th>
                          </thead>
                          <tbody>
                              <?php
                              $sql = mysqli_query($koneksi,"select * from data_padi where kk_nomor='$kkid' order by padi_autoid ASC");
                              while($rs=mysqli_fetch_array($sql)){
                                  
                                  if($rs['2']=="0"){ $rs['2']="-"; }
                                  if($rs['2']=="1"){ $rs['2']="Hibrida"; }
                                  if($rs['2']=="2"){ $rs['2']="Lokal"; }
                                  
                                  if($rs['4']=="0"){ $rs['4']="-"; }
                                  if($rs['4']=="1"){ $rs['4']="Tangkar Sendiri"; }
                                  if($rs['4']=="2"){ $rs['4']="Bantuan Pemerintah"; }
                                  if($rs['4']=="3"){ $rs['4']="Beli"; }
                                  
                                  if($rs['7']=="0"){ $rs['7']="-"; }
                                  if($rs['7']=="1"){ $rs['7']="1 Tahun Sekali"; }
                                  if($rs['7']=="2"){ $rs['7']="2 Tahun Sekali"; }
                                  if($rs['7']=="3"){ $rs['7']="3 Tahun Sekali"; }
                                  
                                  if($rs['8']=="0"){ $rs['8']="-"; }
                                  if($rs['8']=="1"){ $rs['8']="Organik"; }
                                  if($rs['8']=="2"){ $rs['8']="Semi Organik"; }
                                  if($rs['8']=="3"){ $rs['8']="Kimia"; }
                                  
                                  if($rs['9']=="0"){ $rs['9']="-"; }
                                  if($rs['9']=="1"){ $rs['9']="Teknis"; }
                                  if($rs['9']=="2"){ $rs['9']="Non Teknis"; }
                                  if($rs['9']=="3"){ $rs['9']="Tadah Hujan"; }
                                  
                                  if($rs['10']=="0"){ $rs['10']="-"; }
                                  if($rs['10']=="1"){ $rs['10']="Konsumsi Sendiri"; }
                                  if($rs['10']=="2"){ $rs['10']="Konsumsi Sendiri dan Jual"; }
                                  if($rs['10']=="3"){ $rs['10']="Jual"; }
                                  
                                  if($rs['11']=="0"){ $rs['11']="-"; }
                                  if($rs['11']=="1"){ $rs['11']="Milik Pribadi"; }
                                  if($rs['11']=="2"){ $rs['11']="Sewa"; }
                                  if($rs['11']=="3"){ $rs['11']="Bagi Hasil"; }
                                  if($rs['11']=="4"){ $rs['11']="Numpang"; }
                                  
                              ?>
                              <tr>
                                  <td><?php echo $rs['2']; ?></td>
                                  <td><?php echo $rs['3']; ?></td>
                                  <td><?php echo $rs['4']; ?></td>
                                  <td><?php echo $rs['5']; ?> (ha)</td>
                                  <td><?php echo $rs['6']; ?> (ton/Ha)</td>
                                  <td><?php echo $rs['7']; ?></td>
                                  <td><?php echo $rs['8']; ?></td>
                                  <td><?php echo $rs['9']; ?></td>
                                  <td><?php echo $rs['10']; ?></td>
                                  <td><?php echo $rs['11']; ?></td>
                                  <td><a href="anggota_kk_padi_hapus.php?id=<?php echo base64_encode($rs['0']); ?>&uiz=<?php echo base64_encode($kkid); ?>" style="text-decoration:none;" onclick="return confirm('Yakin anda ingin menghapus data ini ? ');">Hapus</a></td>
                              </tr>
                              <?php } ?>
                              <tr>
                                  <td colspan="11"></td>
                              </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Area Data Padi -->
              <!-- Data Pertanian -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-vcenter card-table" border="1">
                          <thead>
                              <td colspan="11">
                                DATA PERTANIAN&nbsp;&nbsp;
                                <a href="anggota_kk_tani_tambah.php?kkid=<?php echo base64_encode($kkid); ?>" class="btn btn-sm btn-primary">TAMBAH DATA</a>
                            </td>
                          </thead>    
                          <thead>
                              <th>Jangka Tanam</th>
                              <th>Jenis Tanaman</th>
                              <th>Luas Lahan<br>(ha)</th>
                              <th>Tegakan (Batang)</th>
                              <th>Umur Tanaman</th>
                              <th>Produktivitas (Ton/Ha)</th>
                              <th>Sistem Budidaya</th>
                              <th>Pemanfaatan Hasil</th>
                              <th>Kepemilikan Lahan</th>
                              <th>&nbsp;</th>
                            </th>
                          </thead>
                          <tbody>
                              <?php
                              $sql = mysqli_query($koneksi,"select * from data_tani where kk_nomor='$kkid' order by tani_autoid ASC");
                              while($rs=mysqli_fetch_array($sql)){
                                  
                                  if($rs['2']=="0"){ $rs['2']="-"; }
                                  if($rs['2']=="1"){ $rs['2']="Jangka Panjang"; }
                                  if($rs['2']=="2"){ $rs['2']="Jangka Pendek&nbsp;<br>( Musiman )"; }
                                  
                                  if($rs['7']=="0"){ $rs['7']="-"; }
                                  if($rs['7']=="1"){ $rs['7']="1 Tahun Sekali"; }
                                  if($rs['7']=="2"){ $rs['7']="2 Tahun Sekali"; }
                                  if($rs['7']=="3"){ $rs['7']="3 Tahun Sekali"; }
                                  
                                  if($rs['8']=="0"){ $rs['8']="-"; }
                                  if($rs['8']=="1"){ $rs['8']="Organik"; }
                                  if($rs['8']=="2"){ $rs['8']="Semi Organik"; }
                                  if($rs['8']=="3"){ $rs['8']="Kimia"; }
                                  
                                  if($rs['9']=="0"){ $rs['9']="-"; }
                                  if($rs['9']=="1"){ $rs['9']="Konsumsi Sendiri"; }
                                  if($rs['9']=="2"){ $rs['9']="Konsumsi Sendiri dan Jual"; }
                                  if($rs['9']=="3"){ $rs['9']="Jual"; }
                                  
                                  if($rs['10']=="0"){ $rs['10']="-"; }
                                  if($rs['10']=="1"){ $rs['10']="Milik Pribadi"; }
                                  if($rs['10']=="2"){ $rs['10']="Sewa"; }
                                  if($rs['10']=="3"){ $rs['10']="Bagi Hasil"; }
                                  if($rs['10']=="4"){ $rs['10']="Numpang"; }
                                  
                              ?>
                              <tr>
                                  <td><?php echo $rs['2']; ?></td>
                                  <td><?php echo $rs['3']; ?></td>
                                  <td><?php echo $rs['4']; ?> (ha)</td>
                                  <td><?php echo $rs['5']; ?></td>
                                  <td><?php echo $rs['6']; ?> (ton/Ha)</td>
                                  <td><?php echo $rs['7']; ?></td>
                                  <td><?php echo $rs['8']; ?></td>
                                  <td><?php echo $rs['9']; ?></td>
                                  <td><?php echo $rs['10']; ?></td>
                                  <td><a href="anggota_kk_tani_hapus.php?id=<?php echo base64_encode($rs['0']); ?>&uiz=<?php echo base64_encode($kkid); ?>" style="text-decoration:none;" onclick="return confirm('Yakin anda ingin menghapus data ini ? ');">Hapus</a></td>
                              </tr>
                              <?php } ?>
                              <tr>
                                  <td colspan="11"></td>
                              </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Area Data Pertanian -->
              <!-- Data Perternakan -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-vcenter card-table" border="1">
                          <thead>
                              <td colspan="11">
                                DATA PERTERNAKAN&nbsp;&nbsp;
                                <a href="anggota_kk_ternak_tambah.php?kkid=<?php echo base64_encode($kkid); ?>" class="btn btn-sm btn-primary">TAMBAH DATA</a>
                            </td>
                          </thead>    
                          <thead>
                              <th>Jenis Ternak</th>
                              <th>Jumlah Ternak</th>
                              <th>Kepemilikan</th>
                              <th>Pemeliharaan</th>
                              <th>&nbsp;</th>
                            </th>
                          </thead>
                          <tbody>
                              <?php
                              $sql = mysqli_query($koneksi,"select * from data_ternak where kk_nomor='$kkid' order by ternak_autoid ASC");
                              while($rs=mysqli_fetch_array($sql)){
                                  
                                  if($rs['2']=="0"){ $rs['2']="-"; }
                                  if($rs['2']=="1"){ $rs['2']="Sapi"; }
                                  if($rs['2']=="2"){ $rs['2']="Kerbau"; }
                                  if($rs['2']=="3"){ $rs['2']="Kambing"; }
                                  if($rs['2']=="4"){ $rs['2']="Ayam"; }
                                  if($rs['2']=="5"){ $rs['2']="Bebek"; }
                                  
                                  if($rs['4']=="0"){ $rs['4']="-"; }
                                  if($rs['4']=="1"){ $rs['4']="Milik Sendiri"; }
                                  if($rs['4']=="2"){ $rs['4']="Bagi Hasil"; }
                                  
                                  if($rs['5']=="0"){ $rs['5']="-"; }
                                  if($rs['5']=="1"){ $rs['5']="Dikandangkan"; }
                                  if($rs['5']=="2"){ $rs['5']="Tidak Dikandangkan"; }
                              ?>
                              <tr>
                                  <td><?php echo $rs['2']; ?></td>
                                  <td><?php echo $rs['3']; ?> Ekor</td>
                                  <td><?php echo $rs['4']; ?></td>
                                  <td><?php echo $rs['5']; ?></td>
                                  <td><a href="anggota_kk_ternak_hapus.php?id=<?php echo base64_encode($rs['0']); ?>&uiz=<?php echo base64_encode($kkid); ?>" style="text-decoration:none;" onclick="return confirm('Yakin anda ingin menghapus data ini ? ');">Hapus</a></td>
                              </tr>
                              <?php } ?>
                              <tr>
                                  <td colspan="11"></td>
                              </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Area Data Perternakan -->
              <!-- Data Perikanan -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-vcenter card-table" border="1">
                          <thead>
                              <td colspan="11">
                                DATA PERIKANAN&nbsp;&nbsp;
                                <a href="anggota_kk_ikan_tambah.php?kkid=<?php echo base64_encode($kkid); ?>" class="btn btn-sm btn-primary">TAMBAH DATA</a>
                            </td>
                          </thead>    
                          <thead>
                              <th>Luas Kolam</th>
                              <th>Jenis Ikan</th>
                              <th>Populasi</th>
                              <th>Masa Panen</th>
                              <th>Pengolahan Pasca Panen</th>
                              <th>Pemanfaatan Hasil</th>
                              <th>Kepemilikan</th>
                              <th>&nbsp;</th>
                            </th>
                          </thead>
                          <tbody>
                              <?php
                              $sql = mysqli_query($koneksi,"select * from data_ikan where kk_nomor='$kkid' order by ikan_autoid ASC");
                              while($rs=mysqli_fetch_array($sql)){
                                  
                                  if($rs['5']=="0"){ $rs['5']="-"; }
                                  if($rs['5']=="1"){ $rs['5']="3 Bulan"; }
                                  if($rs['5']=="2"){ $rs['5']="3 - 5 Bulan"; }
                                  if($rs['5']=="3"){ $rs['5']="> 5 Bulan"; }
                                  
                                  if($rs['6']=="0"){ $rs['6']="-"; }
                                  if($rs['6']=="1"){ $rs['6']="Langsung Dijual"; }
                                  if($rs['6']=="2"){ $rs['6']="Diolah"; }
                                  
                                  if($rs['7']=="0"){ $rs['7']="-"; }
                                  if($rs['7']=="1"){ $rs['7']="Konsumsi Sendiri"; }
                                  if($rs['7']=="2"){ $rs['7']="Konsumsi Sendiri dan Jual"; }
                                  if($rs['7']=="3"){ $rs['7']="Jual"; }
                                  
                                  if($rs['8']=="0"){ $rs['8']="-"; }
                                  if($rs['8']=="1"){ $rs['8']="Milik Pribadi"; }
                                  if($rs['8']=="2"){ $rs['8']="Sewa"; }
                                  if($rs['8']=="3"){ $rs['8']="Bagi Hasil"; }
                                  if($rs['8']=="4"){ $rs['8']="Numpang"; }
                              ?>
                              <tr>
                                  <td><?php echo $rs['2']; ?></td>
                                  <td><?php echo $rs['3']; ?></td>
                                  <td><?php echo $rs['4']; ?> Ekor</td>
                                  <td><?php echo $rs['5']; ?></td>
                                  <td><?php echo $rs['6']; ?></td>
                                  <td><?php echo $rs['7']; ?></td>
                                  <td><?php echo $rs['8']; ?></td>
                                  <td><a href="anggota_kk_ikan_hapus.php?id=<?php echo base64_encode($rs['0']); ?>&uiz=<?php echo base64_encode($kkid); ?>" style="text-decoration:none;" onclick="return confirm('Yakin anda ingin menghapus data ini ? ');">Hapus</a></td>
                              </tr>
                              <?php } ?>
                              <tr>
                                  <td colspan="11"></td>
                              </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Area Data Perikanan -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6">DATA RUMAH TANGGA, ASET KELUARGA</td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Data Perikanan -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-vcenter card-table" border="1">
                          <thead>
                              <td colspan="11">
                                DATA INDUSTRI RUMAH TANGGA&nbsp;&nbsp;
                                <a href="anggota_kk_usaha_tambah.php?kkid=<?php echo base64_encode($kkid); ?>" class="btn btn-sm btn-primary">TAMBAH DATA</a>
                            </td>
                          </thead>    
                          <thead>
                              <th>Jenis Usaha</th>
                              <th>Jenis Produk</th>
                              <th>Jumlah Produk</th>
                              <th>Proses Produksi</th>
                              <th>Pemanfaatan Hasil</th>
                              <th>&nbsp;</th>
                            </th>
                          </thead>
                          <tbody>
                              <?php
                              $sql = mysqli_query($koneksi,"select * from data_usaha where kk_nomor='$kkid' order by usaha_id ASC");
                              while($rs=mysqli_fetch_array($sql)){
                                  
                                  if($rs['2']=="0"){ $rs['2']="-"; }
                                  if($rs['2']=="1"){ $rs['2']="Makanan Olahan"; }
                                  if($rs['2']=="2"){ $rs['2']="Kerajinan"; }
                                  if($rs['2']=="3"){ $rs['2']="Jasa"; }
                                  
                                  if($rs['5']=="0"){ $rs['5']="-"; }
                                  if($rs['5']=="1"){ $rs['5']="Mesin"; }
                                  if($rs['5']=="2"){ $rs['5']="Semi Mesin"; }
                                  if($rs['5']=="3"){ $rs['5']="Manual"; }
                                  
                                  if($rs['6']=="0"){ $rs['6']="-"; }
                                  if($rs['6']=="1"){ $rs['6']="Dipakai Sendiri"; }
                                  if($rs['6']=="2"){ $rs['6']="Dipakai Sendiri dan Jual"; }
                                  if($rs['6']=="3"){ $rs['6']="Jual"; }
                              ?>
                              <tr>
                                  <td><?php echo $rs['2']; ?></td>
                                  <td><?php echo $rs['3']; ?></td>
                                  <td><?php echo $rs['4']; ?></td>
                                  <td><?php echo $rs['5']; ?></td>
                                  <td><?php echo $rs['6']; ?></td>
                                  <td><a href="anggota_kk_usaha_hapus.php?id=<?php echo base64_encode($rs['0']); ?>&uiz=<?php echo base64_encode($kkid); ?>" style="text-decoration:none;" onclick="return confirm('Yakin anda ingin menghapus data ini ? ');">Hapus</a></td>
                              </tr>
                              <?php } ?>
                              <tr>
                                  <td colspan="11"></td>
                              </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Area Data Perikanan -->
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
              <div class="row align-items-center">
                <div class="col-auto">
                  <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="./docs/index.php">Documentation</a></li>
                    <li class="list-inline-item"><a href="./faq.html">FAQ</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright © <?php echo date('Y'); ?> <a href=".">SiPeta</a>. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  </body>
</html>
