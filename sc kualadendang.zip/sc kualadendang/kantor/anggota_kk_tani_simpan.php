<?php include('tunnel.php'); 

$padi_id = base64_decode($_POST['tani_id']);
$padi_jn = $_POST['tani_jangka'];
$padi_vr = $_POST['tani_jenis'];
$padi_sb = $_POST['tani_luas'];
$padi_ls = $_POST['tani_tegak'];
$padi_pr = $_POST['tani_umur'];
$padi_pl = $_POST['tani_produk'];
$padi_st = $_POST['tani_sistem'];
$padi_ar = $_POST['tani_hasil'];
$padi_hs = $_POST['tani_milik'];


$sql="INSERT INTO `data_tani`(`tani_autoid`, `kk_nomor`, `tani_jangka`, `tani_jenis`, `tani_luas`, `tani_batang`, `tani_umur`, `tani_produk`, `tani_sistem`, `tani_hasil`, `tani_lahan`) 
VALUES (NULL,'$padi_id','$padi_jn','$padi_vr','$padi_sb','$padi_ls','$padi_pr','$padi_pl','$padi_st','$padi_ar','$padi_hs')";

mysqli_query($koneksi,$sql);

?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo base64_encode($padi_id); ?>"</script>