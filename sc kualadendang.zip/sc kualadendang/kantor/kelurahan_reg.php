<?php

include('tunnel.php');

$kel_uid      = md5(microtime());
$kel_nama     = $_POST['kel_nama'];
$kec_id       = $_POST['kec_id'];

$sql = "INSERT INTO kelurahan (kel_id, kel_uid, kel_nama, kec_id)
VALUES (NULL, '$kel_uid','$kel_nama','$kec_id');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kelurahan.php";</script>
