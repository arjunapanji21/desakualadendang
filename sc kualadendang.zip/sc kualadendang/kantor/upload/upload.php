<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php include('../tunnel.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="" /> 
<meta name="keywords" content="" />
<meta name="author" content="Feliks Lourensius" />
<title>Upload script</title>
</head>

<body>
<p>
  <?php
	
	
	$autoidz=($_POST['autoidz']);
	
	if(!isset($autoidz)){ 
	?>
	<script>window.location.href="google.com";</script>
	<?php
	    
	}
	$nama_foto = $_POST['fname'];
	// Membaca nama file
	$file_name = $_FILES['fupload']['name'];

	// Membaca ukuran file
	$size = $_FILES['fupload']['size'];

	// Membaca jenis file
	$file_type = $_FILES['fupload']['type'];
	
	// Source tempat upload file sementara
	$source = $_FILES['fupload']['tmp_name'];

	$key = "RUMAH";
	$time = microtime();
	$new_phrase = $key."-".$time."-".$file_name;
	$file_name = md5($new_phrase);
	$type="jpg";
	if($file_type=="image/gif"){ $type ="gif"; }
	if($file_type=="image/jpg"){ $type ="jpg"; }
	if($file_type=="image/jpeg"){ $type ="jpeg"; }
	if($file_type=="image/png"){ $type ="png"; }
	$file_name = $file_name.".".$type;
	
	// Tempat upload file disimpan
	$direktori = "files/$file_name";
	
	// Mengecek apakah file yang di upload sudah ada atau belum
	if( file_exists ($direktori)) {
		echo "file <strong>$file_name</strong> sudah ada, upload dengan nama lain <br/> <a href=\"index.php?autoid=<?php echo $autoidz ?>\">kembali</a>";
		exit();
	} elseif ($file_type != "image/gif" && $file_type != "image/jpg" && $file_type != "image/jpeg" && $file_type != "image/png") {
		echo $file_type."<br/>";
		echo "file <strong>$file_name</strong> tidak di support, hanya untuk upload gambar (gif, jpg,jpef,png)";
	} else {

	// Memindahkan upload file dari direktori sementara ke tempat permanen
	move_uploaded_file($source,$direktori);

	echo "File Berhasil di upload !";
	
	$key = "K";
	$phrase = $key."-".microtime();
	$kuid = md5($phrase);
	
	mysqli_query($koneksi,"INSERT INTO data_files VALUES ('','$kuid','$autoidz',NOW(),'$userid','$nama_foto','$file_name'); ");
	
	}
	
?>

</p>
<p><a href="index.php?autoid=<?php echo $autoidz ?>" style="text-decoration:none;text-decoration-color: blue" ><button>Upload lagi</button></a> - 
<button onclick="javascript:window.close('','_parent','');">Selesai</button></p>
</body>
</html>
