<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="PHP script upload file" /> 
<meta name="keywords" content="PHP tutorial, PHP" />
<meta name="author" content="kinta mahadji" />
<title>Closing</title>
<script>
  window.opener.location.reload();
  window.close();
</script>
</head>

<body>
</body>
</html>
