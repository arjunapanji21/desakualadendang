<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php

$autoidz=($_GET['kkid']);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="PHP script upload file" /> 
<meta name="keywords" content="PHP tutorial, PHP" />
<meta name="author" content="kinta mahadji" />
<title>Upload File penunjang</title>
</head>

<body>
<form action="upload.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <h3>Upload file :</h3>
    <label>Masukan Nama Foto</label><br>
    <input type="text" name="fname"><br>
    <label>Masukan Foto</label><br>
    <input type="file" name="fupload" /><input type="hidden" name="autoidz" value="<?php echo $autoidz ?>"><hr><input type="submit" name="upload" value="Upload" />
    <br><br><a href="close.php" style="text-decoration:none;text-decoration-color: blue" onclick="window.close();">Batal Upload</a>
</form>
</body>
</html>
