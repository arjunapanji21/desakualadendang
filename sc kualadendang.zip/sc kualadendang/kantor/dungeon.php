<?php
	$host="localhost";
	$user="root";
	$pw="Dendang2020";
	$db="sytem_dendang";

	$koneksi=mysqli_connect($host,$user,$pw,$db) or die ("Koneksi gagal");
?>
