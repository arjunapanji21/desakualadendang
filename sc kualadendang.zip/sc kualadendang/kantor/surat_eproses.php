<?php

include('tunnel.php');

$sur_uid      = md5(microtime());
$sur_tanggal  = $_POST['surat_tanggal'];
$sur_nomor    = $_POST['surat_nomor'];
$sur_jenis    = $_POST['surat_jenis'];
$sur_instansi = $_POST['surat_instansi'];
$sur_tebusan  = $_POST['surat_tebusan'];
$sur_judul    = $_POST['surat_judul'];
$sur_ket      = $_POST['surat_keterangan'];
$sur_uid      = $_POST['surat_uid'];

$sql = "UPDATE surat set sur_nosurat='$sur_nomor', sur_instansi='$sur_instansi', sur_kat='$sur_jenis', sur_judul='$sur_judul', sur_keterangan='$sur_ket', sur_edit=NOW(), sur_aedit='$userid' where sur_uid='$sur_uid'";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.alert('Surat berhasil diperbaharui');</script>
<script>window.location.href="surat.php";</script>
