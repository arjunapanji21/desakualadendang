<?php

include('tunnel.php');

$kwartir_uid      = md5(microtime());
$kwartir_kode     = $_POST['kwartir_kode'];
$kwartir_nama     = $_POST['kwartir_nama'];
$kwartir_tempat   = $_POST['kwartir_tempat'];
$kwartir_ranting  = $_POST['kwartir_ranting'];
$kwartir_lurah    = $_POST['kwartir_lurah'];
$kwartir_cabang   = $_POST['kwartir_cabang'];

$sql = "INSERT INTO instansi (ins_id, ins_uid, ins_kode, ins_nama, ins_alamat, ins_kecamatan, ins_kelurahan, ins_kabupaten)
VALUES (NULL, '$kwartir_uid','$kwartir_kode','$kwartir_nama','$kwartir_tempat','$kwartir_ranting','$kwartir_lurah','$kwartir_cabang');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="instansi.php";</script>
