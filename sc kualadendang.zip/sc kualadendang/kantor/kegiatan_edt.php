<?php

include('tunnel.php');

$keg_uid      = $_POST['keg_uid'];
$keg_nama     = $_POST['keg_nama'];
$keg_tentang  = $_POST['keg_tentang'];
$keg_mulai    = $_POST['keg_mulai'];
$keg_selesai  = $_POST['keg_selesai'];

$sql = "UPDATE kegiatan set keg_judul='$keg_nama',keg_keterangan='$keg_tentang',keg_datestart='$keg_mulai',keg_dateend='$keg_selesai' where keg_uid='$keg_uid';";

//echo $sql;
mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kegiatan.php";</script>
