<?php

include('tunnel.php');

$sur_uid      = md5(microtime());
$job_nama     = $_POST['nama_job'];

$sql = "INSERT INTO pekerjaan (job_id, job_nama)
VALUES (NULL,'$job_nama');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="pengaturan.php";</script>
