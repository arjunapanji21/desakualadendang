<?php

include('tunnel.php');

$kwartir_uid      = $_POST['uid'];
$kwartir_kode     = $_POST['kwartir_kode'];
$kwartir_nama     = $_POST['kwartir_nama'];
$kwartir_tempat   = $_POST['kwartir_tempat'];
$kwartir_ranting  = $_POST['kwartir_ranting'];
$kwartir_lurah    = $_POST['kwartir_lurah'];
$kwartir_cabang   = $_POST['kwartir_cabang'];

$sql = "UPDATE instansi set ins_kode='$kwartir_kode',ins_nama='$kwartir_nama',ins_alamat='$kwartir_tempat',ins_kecamatan='$kwartir_ranting',ins_kelurahan='$kwartir_lurah',ins_kabupaten='$kwartir_cabang' where ins_uid='$kwartir_uid';";
//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="instansi.php";</script>
