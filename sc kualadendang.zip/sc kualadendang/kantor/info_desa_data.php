<?php
include('tunnel.php');

$cek_pesan1 = $rsdatapeta['conf_pesan1'];
$cek_pesan2 = $rsdatapeta['conf_pesan2'];

$pesan_1 = $_POST['papan_1'];
$pesan_2 = $_POST['papan_2'];


if($cek_pesan1 != $pesan_1){
    mysqli_query($koneksi,"UPDATE config set conf_pesan1='$pesan_1', conf_pesan1date=NOW()");
}
if($cek_pesan2 != $pesan_2){
    mysqli_query($koneksi,"UPDATE config set conf_pesan2='$pesan_2', conf_pesan2date=NOW()");
}

?>
<script>window.alert('Data Pengumuman berhasil diperbaharui');</script>
<script>window.location.href="info_desa.php"</script>