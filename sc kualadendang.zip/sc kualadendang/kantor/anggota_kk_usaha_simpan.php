<?php include('tunnel.php'); 

$padi_id = base64_decode($_POST['ternak_id']);
$padi_jn = $_POST['usaha_jenis'];
$padi_vr = $_POST['usaha_produk'];
$padi_sb = $_POST['usaha_jumlah'];
$padi_ls = $_POST['usaha_proses'];
$padi_pr = $_POST['usaha_manfaat'];

$sql="INSERT INTO `data_usaha`(`usaha_id`, `kk_nomor`, `usaha_jenis`, `usaha_produk`, `usaha_jumlah`, `usaha_proses`, `usaha_hasil`) 
VALUES (NULL,'$padi_id','$padi_jn','$padi_vr','$padi_sb','$padi_ls','$padi_pr');";


mysqli_query($koneksi,$sql);

?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo base64_encode($padi_id); ?>"</script>