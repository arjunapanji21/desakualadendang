<?php include('tunnel.php'); ?>
<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Language" content="en" />
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <link rel="icon" href="./assets/images/logo/pramuka.png" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/images/logo/pramuka.png" />
    <!-- Generated: 2018-04-16 09:29:05 +0200 -->
    <title>Keuangan - SiPETA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">
    <script src="./assets/js/require.min.js"></script>
    <script>
      requirejs.config({
          baseUrl: '.'
      });
    </script>
    <!-- Dashboard Core -->
    <link href="./assets/css/dashboard.css" rel="stylesheet" />
    <script src="./assets/js/dashboard.js"></script>
    <!-- c3.js Charts Plugin -->
    <link href="./assets/plugins/charts-c3/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/charts-c3/plugin.js"></script>
    <!-- Google Maps Plugin -->
    <link href="./assets/plugins/maps-google/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/maps-google/plugin.js"></script>
    <!-- Input Mask Plugin -->
    <script src="./assets/plugins/input-mask/plugin.js"></script>
    <script>
      require(['datatables'], function() {
          $(document).ready(function () {
              $('#table').DataTable({
              });
          });
      });
    </script>
    <link href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css" rel="stylesheet" />
  </head>
  <body class="">
    <div class="page">
      <div class="page-main">
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="./index.php">
                <img src="./assets/images/logo/pramuka.png" class="header-brand-img" alt="tabler logo"> SiPETA
              </a>
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(./demo/faces/female/25.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo $user; ?></span>
                      <small class="text-muted d-block mt-1"><?php echo $usergugus; ?></small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <?php include('menu_profile.php'); ?>
                  </div>
                </div>
              </div>
              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3 ml-auto">
                <form class="input-icon my-3 my-lg-0">
                  <input type="search" class="form-control header-search" placeholder="Search&hellip;" tabindex="1">
                  <div class="input-icon-addon">
                    <i class="fe fe-search"></i>
                  </div>
                </form>
              </div>
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="./index.php" class="nav-link"><i class="fe fe-home"></i> Home</a>
                  </li>
                  <li class="nav-item">
                    <a href="./info_desa.php" class="nav-link"><i class="fe fe-award"></i> Info Desa</a>
                  </li>
                  <li class="nav-item">
                    <a href="./anggota.php" class="nav-link"><i class="fe fe-users"></i> Penduduk</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Statistik</a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link active" data-toggle="dropdown"><i class="fe fe-box"></i> Sekretariat</a>
                    <div class="dropdown-menu dropdown-menu-arrow">
                      <a href="surat.php" class="dropdown-item ">Layanan Surat</a>
                      <a href="keuangan.php" class="dropdown-item ">Keuangan</a>
                      <a href="pertanahan.php" class="dropdown-item ">Pertanahan</a>
                      <a href="sms.php" class="dropdown-item ">SMS</a>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Analisis</a>
                  </li>
                  <li class="nav-item">
                    <a href="pengaturan.php" class="nav-link"><i class="fe fe-settings"></i> Pengaturan</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Admin Web</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title">
                Edit Transaksi <?php echo $usergugus; ?>
              </h1>
            </div>
            <?php
            $uid = $_GET['uid'];
            if(!isset($_GET['uid'])){
                ?>
                <script>window.location.href="keuangan.php";</script>
                <?php
            }
            $rs = mysqli_fetch_array(mysqli_query($koneksi,"select * from transaksi where trans_uid='$uid'"));
            $stat = $rs['trans_stat'];
            ?>
            <form action="keuangan_eproses.php" method="POST">
                  <div class="row row-cards row-deck">
                  <div class="col-12">
                    <form action="keuangan_eproses.php" method="POST">
                      <div class="form-group">
                        <label class="form-label">Tanggal Transaksi</label>
                        <input type="text" class="form-control" name="keu_tanggal" value="<?php echo dtostr($rs['trans_date']); ?>" disabled>
                      </div>
                      <div class="row">
                          <div class="col-6">
                            <label class="form-label">Nomor Nota / Kwitansi</label>
                            <input type="text" class="form-control" name="keu_nota" placeholder="Nomor Nota / Kwitansi" value="<?php echo $rs['trans_nonota']; ?>">
                          </div>
                          <div class="col-6">
                            <label class="form-label">Jenis Transaksi</label>
                            <select class="form-control" name="keu_jenis">
                              <option value="0">Pilih Jenis Transaksi</option>
                              <?php
                              $query_jenis = mysqli_query($koneksi,"select * from transaksi_jenis");
                              while($rs_jenis = mysqli_fetch_array($query_jenis)){
                              ?>
                                <option value="<?php echo $rs_jenis['tjen_stat']; ?>" <?php if($stat==$rs_jenis['tjen_stat']){ echo "selected"; } ?>><?php echo $rs_jenis['tjen_nama']; ?></option>
                              <?php } ?>
                            </select>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-6">
                            <label class="form-label">Intansi</label>
                            <input type="text" class="form-control" name="keu_instansi" placeholder="Instansi" value="<?php echo $rs['trans_instansi']; ?>">
                          </div>
                          <div class="col-6">
                            <label class="form-label">Nominal</label>
                            <input type="number" class="form-control" name="keu_nominal" placeholder="Nominal Cth : 5000" value="<?php echo $rs['trans_nominal']; ?>">
                          </div>
                      </div>
                      <div class="form-group">
                        <label class="form-label">Keterangan</label>
                        <input type="text" class="form-control" name="keu_keterangan" placeholder="Keterangan Transaksi" value="<?php echo $rs['trans_keterangan']; ?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label">Catatan</label>
                        <textarea class="form-control" name="keu_catatan" rows="5" placeholder="Catatan Transaksi"><?php echo $rs['trans_catatan']; ?></textarea>
                        <input type="hidden" name="keu_id" id="keu_id" value="<?php echo $uid; ?>">
                      </div>
                      <div class="form-group">
                        <input type="submit" class="btn btn-success" value="SIMPAN">&nbsp;&nbsp;
                      </form>
                        <font size="4"><a href="surat.php" style="text-decoration:none;">Kembali</a></font>
                      </div>
                  </div>
                </div>
              </form>
            
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
              <div class="row align-items-center">
                <div class="col-auto">
                  <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="./docs/index.php">Documentation</a></li>
                    <li class="list-inline-item"><a href="./faq.html">FAQ</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright © <?php echo date('Y'); ?> <a href=".">SiPeta</a>. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  </body>
</html>
