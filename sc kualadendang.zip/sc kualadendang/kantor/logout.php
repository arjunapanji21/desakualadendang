<?php
	include("dungeon.php");
	session_start();
  $user      = $_SESSION['user'];
	$userid    = $_SESSION['userid'];
	$userlevel = $_SESSION['userlevel'];
	$usergugus = $_SESSION['usergugus'];
	session_destroy();
	header("location:index.php");
?>
