<div class="page">
      <div class="page-main">
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="./index.php">
                <img src="./assets/images/logo/pramuka.png" class="header-brand-img" alt="tabler logo"> SiPETA
              </a>
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(./demo/faces/female/25.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo $user; ?></span>
                      <small class="text-muted d-block mt-1"><?php echo $usergugus; ?></small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <?php include('menu_profile.php'); ?>
                  </div>
                </div>
              </div>
              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3 ml-auto">
                <form class="input-icon my-3 my-lg-0">
                  <input type="search" class="form-control header-search" placeholder="Search&hellip;" tabindex="1">
                  <div class="input-icon-addon">
                    <i class="fe fe-search"></i>
                  </div>
                </form>
              </div>
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="./index.php" class="nav-link active"><i class="fe fe-home"></i> Home</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title">
                Halo, <?php echo $user; ?>
              </h1>
            </div>
            <div class="row row-cards row-deck">
              <div class="col-lg-6">
                <div class="card card-aside">
                  <a href="#" class="card-aside-column" style="background-image: url(./assets/images/logo/pramuka.png)"></a>
                  <div class="card-body d-flex flex-column">
                    <h4><a href="#">25 November 2020.</a></h4>
                    <div class="text-muted">Selamat Hari Guru Nasional 2020</div>
                    <div class="d-flex align-items-center pt-5 mt-auto">
                      <div class="avatar avatar-md mr-3" style="background-image: url(./assets/images/logo/pramuka.png)"></div>
                      <div>
                        <a href="./profile.html" class="text-default">ADMIN SiPETA</a>
                        <small class="d-block text-muted">Hari ini</small>
                      </div>
                      <div class="ml-auto text-muted">
                        <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="card card-aside">
                  <a href="#" class="card-aside-column" style="background-image: url(./assets/images/logo/pramuka.png)"></a>
                  <div class="card-body d-flex flex-column">
                    <h4><a href="#">INFORMASI SiPETA</a></h4>
                    <div class="text-muted">Pastikan anda selalu logut setelah menggunakan aplikasi ini.</div>
                    <div class="d-flex align-items-center pt-5 mt-auto">
                      <div class="avatar avatar-md mr-3" style="background-image: url(./assets/images/logo/pramuka.png)"></div>
                      <div>
                        <a href="./profile.html" class="text-default">ADMIN SiPETA</a>
                        <small class="d-block text-muted">-</small>
                      </div>
                      <div class="ml-auto text-muted">
                        <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i class="fe fe-heart mr-1"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row row-cards row-deck">
              <div class="col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Kegiatan Berjalan Bulan Ini</h3>
                  </div>
                  <div class="card-body o-auto" style="height: 15rem">
                    <ul class="list-unstyled list-separated">
                      <?php
                      $query_kegiatan = mysqli_query($koneksi,"select * from kegiatan where keg_ins='$userinsta' order by keg_id DESC limit 3");
                      while($rs_kegiatan=mysqli_fetch_array($query_kegiatan)){

                        $instansi = $rs_kegiatan['2'];

                        $rs_instansi = mysqli_fetch_array(mysqli_query($koneksi,"select ins_nama from instansi where ins_uid ='$instansi'"));
                        $ins_nama = $rs_instansi['ins_nama'];

                      ?>
                      <li class="list-separated-item">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <span class="avatar avatar-md d-block" style="background-image: url(assets/images/logo/pramuka.png)"></span>
                          </div>
                          <div class="col">
                            <div>
                              <a href="javascript:void(0)" class="text-inherit"><?php echo $rs_kegiatan['5']; ?> ( <?php echo dtostr($rs_kegiatan['3']); ?> - <?php echo dtostr($rs_kegiatan['4']); ?> ) </a>
                            </div>
                            <small class="d-block item-except text-sm text-muted h-1x"><?php echo $rs_kegiatan['6']; ?></small>
                          </div>
                        </div>
                      </li>
                      <?php } ?>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
              <div class="row align-items-center">
                <div class="col-auto">
                  <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="./docs/index.php">Documentation</a></li>
                    <li class="list-inline-item"><a href="./faq.html">FAQ</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright © <?php echo date('Y'); ?> <a href=".">SiPeta</a>. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>