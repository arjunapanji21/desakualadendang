<?php

include('tunnel.php');

$kec_uid      = $_GET['uid'];

$sql = "DELETE FROM kecamatan where kec_uid='$kec_uid';";
//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kecamatan.php";</script>
