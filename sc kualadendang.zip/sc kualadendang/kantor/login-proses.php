<?php
  session_start();
  error_reporting(0);
  include("dungeon.php");

	$email   =$_POST['email'];
	$password=sha1($_POST['password']);

	$query=mysqli_query($koneksi,"SELECT * FROM anggota WHERE ang_email='$email' AND ang_password='$password'");
	$jumlah=mysqli_num_rows($query);

	if ($jumlah>0) {
		$rsuser=mysqli_fetch_array($query);
    $gugusdepan = $rsuser['ang_job'];
    $rsgugusdepan = mysqli_fetch_array(mysqli_query($koneksi,"select job_nama from pekerjaan where job_id='$gugusdepan'"));

		$_SESSION['user']       = $rsuser['ang_nama'];
		$_SESSION['userid']	    = $rsuser['ang_uid'];
		$_SESSION['userlevel']	= $rsuser['ang_level'];
		$_SESSION['userjob']	= $rsgugusdepan['job_nama'];
		header("location:index.php");
	}else{
		?><script language="javascript">alert("Email atau Password anda Salah");</script> <?php
		?><script language="javascript">document.location.href="login.html";</script> <?php
	}
?>
