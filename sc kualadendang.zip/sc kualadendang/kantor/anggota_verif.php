<?php

include('tunnel.php');

$kab_uid      = $_GET['uid'];

$sql = "UPDATE anggota set ang_aktif='1' where ang_uid='$kab_uid';";
//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="anggota_list.php";</script>
