<?php
include('tunnel.php');
$kkid=base64_decode($_GET['zass']);


$var1 = $_POST['kk_dusun'];
$var2 = $_POST['kk_rt'];
$var3 = $_POST['kk_rw'];
$var4 = $_POST['kk_hp'];
$var5 = $_POST['kk_email'];
$var5s= $_POST['kk_lokas'];
$var6 = $_POST['kk_lat'];
$var7 = $_POST['kk_lon'];

//Proses update DATA KK
mysqli_query($koneksi,"UPDATE `data_kk` SET `kk_dusun`='$var1',`kk_rt`='$var2',`kk_rw`='$var3',`kk_nohp`='$var4',`kk_email`='$var5',`kk_lokasi`='$var5s',`kk_latitude`='$var6',`kk_longitude`='$var7' WHERE kk_nomor='$kkid'");


$var8 = $_POST['kel_listrik'];
$var9 = $_POST['kel_daya'];
$var10= $_POST['kel_masak'];
$var11= $_POST['kel_air'];
$var12= $_POST['kel_mck'];
$var13= $_POST['kel_bangunan'];
$var14= $_POST['kel_kons'];
$var15= $_POST['kel_rumah'];

//Proses update DATA Keluarga
mysqli_query($koneksi,"UPDATE `data_keluarga` SET `kel_listrik`='$var8',`kel_daya`='$var9',`kel_masak`='$var10',`kel_air`='$var11',`kel_mck`='$var12',`kel_bangun`='$var13',`kel_konstruksi`='$var14',`kel_rumah`='$var15' WHERE kk_nomor='$kkid'");


$var16= $_POST['pen_beras'];
$var17= $_POST['pen_lauk'];
$var18= $_POST['pen_sayur'];
$var19= $_POST['pen_bumbu'];
$var20= $_POST['pen_rokok'];
$var21= $_POST['pen_air'];

$var22= $_POST['pen_minyak'];
$var23= $_POST['pen_gas'];
$var24= $_POST['pen_listrik'];
$var25= $_POST['pen_bbm'];

$var26= $_POST['pen_pupuk'];
$var27= $_POST['pen_racun'];
$var28= $_POST['pen_benih'];
$var29= $_POST['pen_upah'];
$var30= $_POST['pen_sewa'];
$var31= $_POST['pen_transport'];

$var32= $_POST['pen_spp'];
$var33= $_POST['pen_kost'];
$var34= $_POST['pen_sekolah'];

$var35= $_POST['pen_sehat'];
$var36= $_POST['pen_obat'];
$var37= $_POST['pen_energi'];

$var38= $_POST['pen_pulsa'];

$var39= $_POST['pen_iuran'];
$var40= $_POST['pen_sumbangan'];
$var41= $_POST['pen_arisan'];

$var42= $_POST['pen_hiburan'];
$var43= $_POST['pen_tabungan'];

//Proses update DATA Pengeluaran
mysqli_query($koneksi,"UPDATE `data_pengeluaran` SET `peng_bel1`='$var16',`peng_bel2`='$var17',`peng_bel3`='$var18',`peng_bel4`='$var19',`peng_bel5`='$var20',`peng_bel6`='$var21',`peng_ener1`='$var22',`peng_ener2`='$var23',`peng_ener3`='$var24',`peng_ener4`='$var25',`peng_usaha1`='$var26',`peng_usaha2`='$var27',`peng_usaha3`='$var28',`peng_usaha4`='$var29',`peng_usaha5`='$var30',`peng_usaha6`='$var31',`peng_pend1`='$var32',`peng_pend2`='$var33',`peng_pend3`='$var34',`peng_kes1`='$var35',`peng_kes2`='$var36',`peng_kes3`='$var37',`peng_kom1`='$var38',`peng_sos1`='$var39',`peng_sos2`='$var40',`peng_sos3`='$var41',`peng_lain1`='$var42',`peng_lain2`='$var43' WHERE kk_nomor='$kkid'");


$ast1= $_POST['aset_lahan'];
$ast2= $_POST['aset_traktor'];
$ast3= $_POST['aset_rumah'];
$ast4= $_POST['aset_mesin'];
$ast5= $_POST['aset_jahit'];
$ast6= $_POST['aset_bangun'];
$ast7= $_POST['aset_motor'];
$ast8= $_POST['aset_usaha'];
$ast9= $_POST['aset_mobil'];
$ast10= $_POST['aset_lain'];


//Proses update DATA Aset
mysqli_query($koneksi,"UPDATE `data_aset` SET `aset_1`='$ast1',`aset_2`='$ast2',`aset_3`='$ast3',`aset_4`='$ast4',`aset_5`='$ast5',`aset_6`='$ast6',`aset_7`='$ast7',`aset_8`='$ast8',`aset_9`='$ast9',`aset_10`='$ast10' WHERE kk_nomor='$kkid'");


?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo $_GET['zass'] ?>";</script>


