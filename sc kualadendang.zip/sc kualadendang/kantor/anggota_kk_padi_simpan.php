<?php include('tunnel.php'); 

$padi_id = base64_decode($_POST['padi_id']);
$padi_jn = $_POST['padi_jenis'];
$padi_vr = $_POST['padi_varietas'];
$padi_sb = $_POST['padi_sumber'];
$padi_ls = $_POST['padi_luas'];
$padi_pr = $_POST['padi_produk'];
$padi_pl = $_POST['padi_pola'];
$padi_st = $_POST['pagi_sistem'];
$padi_ar = $_POST['padi_air'];
$padi_hs = $_POST['padi_hasil'];
$padi_ml = $_POST['padi_milik'];


$sql="INSERT INTO `data_padi`(`padi_autoid`, `kk_nomor`, `padi_jenis`, `padi_vari`, `padi_sumber`, `padi_luas`, `padi_produk`, `padi_pola`, `padi_sistem`, `padi_air`, `padi_hasil`, `padi_lahan`) 
VALUES (NULL,'$padi_id','$padi_jn','$padi_vr','$padi_sb','$padi_ls','$padi_pr','$padi_pl','$padi_st','$padi_ar','$padi_hs','$padi_ml')";

mysqli_query($koneksi,$sql);

?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo base64_encode($padi_id); ?>"</script>