<?php

	$host="localhost";
	$user="root";
	$pw="Dendang2020";
	$db="sytem_dendang";


	$koneksi=mysqli_connect($host,$user,$pw,$db) or die ("Koneksi gagal");


	function dtosql($date){
	$exp = explode('/',$date);
	if(count($exp) == 3) {
		$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
	}
	return $date;
	}

	function dtostr($date){
	$exp = explode('-',$date);
	if(count($exp) == 3) {
		$date = $exp[2].'/'.$exp[1].'/'.$exp[0];
	}
	return $date;
	}

	function dtotext($date){
	$exp = explode('-',$date);
		$month = $exp[1];

		if($month==1){ $month="Januari"; }
		if($month==2){ $month="Februari"; }
		if($month==3){ $month="Maret"; }
		if($month==4){ $month="April"; }
		if($month==5){ $month="Mei"; }
		if($month==6){ $month="Juni"; }

		if($month==7){ $month="Juli"; }
		if($month==8){ $month="Agustus"; }
		if($month==9){ $month="September"; }
		if($month==10){ $month="Oktober"; }
		if($month==11){ $month="November"; }
		if($month==12){ $month="Desember"; }

	return $month;
	}

	function dtotgl($date){
		$exp = explode('-',$date);
			$month = $exp[1];
			$day   = $exp[2];
			$year  = $exp[0];
	
			if($month==1){ $month="Januari"; }
			if($month==2){ $month="Februari"; }
			if($month==3){ $month="Maret"; }
			if($month==4){ $month="April"; }
			if($month==5){ $month="Mei"; }
			if($month==6){ $month="Juni"; }
	
			if($month==7){ $month="Juli"; }
			if($month==8){ $month="Agustus"; }
			if($month==9){ $month="September"; }
			if($month==10){ $month="Oktober"; }
			if($month==11){ $month="November"; }
			if($month==12){ $month="Desember"; }
		
			$new = $day.' '.$month.' '.$year;

		return $new;
		}

	function hitung_umur($tanggal_lahir){
		$tgl = date('Y-m-d', strtotime($tanggal_lahir));
		$umur = floor(time() - strtotime($tgl))/(60*60*24*365);
		$umur = round($umur);

		return $umur." tahun ";
	}

	$today=date("Y-m-d");
	$sekarang=date("Y-m-d");
	$bulan_sekarang = date('m');
	$tahun_sekarang = date('Y');


	session_start();
	$user      = $_SESSION['user'];
	$userid    = $_SESSION['userid'];
	$userlevel = $_SESSION['userlevel'];
	$usergugus = "Desa Kuala Dendang";
	$userjob   = $_SESSION['userjob'];
	if(!isset($user)){
		header('Location: login.html');
	}else{
	    $rsdatapeta=mysqli_fetch_array(mysqli_query($koneksi,"select * from config"));
	}
?>
