<?php include('tunnel.php'); $kkid=base64_decode($_GET['kkid']);?>
<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Language" content="en" />
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <link rel="icon" href="./assets/images/logo/pramuka.png" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="./assets/images/logo/pramuka.png" />
    <!-- Generated: 2018-04-16 09:29:05 +0200 -->
    <title>Tambah Data Tani - SiPETA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">
    <script src="./assets/js/require.min.js"></script>
    <script>
      requirejs.config({
          baseUrl: '.'
      });
    </script>
    <!-- Dashboard Core -->
    <link href="./assets/css/dashboard.css" rel="stylesheet" />
    <script src="./assets/js/dashboard.js"></script>
    <!-- c3.js Charts Plugin -->
    <link href="./assets/plugins/charts-c3/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/charts-c3/plugin.js"></script>
    <!-- Google Maps Plugin -->
    <link href="./assets/plugins/maps-google/plugin.css" rel="stylesheet" />
    <script src="./assets/plugins/maps-google/plugin.js"></script>
    <!-- Input Mask Plugin -->
    <script src="./assets/plugins/input-mask/plugin.js"></script>
    <script>
      require(['datatables'], function() {
          $(document).ready(function () {
              $('#table').DataTable({
              });
          });
      });
    </script>
    <link href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css" rel="stylesheet" />
  </head>
  <body class="">
    <div class="page">
      <div class="page-main">
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="./index.php">
                <img src="./assets/images/logo/pramuka.png" class="header-brand-img" alt="tabler logo"> SiPETA
              </a>
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(./demo/faces/female/25.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo $user; ?></span>
                      <small class="text-muted d-block mt-1"><?php echo $usergugus; ?></small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <?php include('menu_profile.php'); ?>
                  </div>
                </div>
              </div>
              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3 ml-auto">
              </div>
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="./index.php" class="nav-link"><i class="fe fe-home"></i> Home</a>
                  </li>
                  <li class="nav-item">
                    <a href="./info_desa.php" class="nav-link"><i class="fe fe-award"></i> Info Desa</a>
                  </li>
                  <li class="nav-item">
                    <a href="./anggota.php" class="nav-link active"><i class="fe fe-users"></i> Penduduk</a>
                  </li>
                  <li class="nav-item">
                    <a href="statistik.php" class="nav-link"><i class="fe fe-users"></i> Statistik</a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown"><i class="fe fe-box"></i> Sekretariat</a>
                    <div class="dropdown-menu dropdown-menu-arrow">
                      <a href="surat.php" class="dropdown-item ">Layanan Surat</a>
                      <a href="keuangan.php" class="dropdown-item ">Keuangan</a>
                      <a href="#" class="dropdown-item ">Pertanahan</a>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Analisis</a>
                  </li>
                  <li class="nav-item">
                    <a href="pengaturan.php" class="nav-link"><i class="fe fe-settings"></i> Pengaturan</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Admin Web</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title">
                TAMBAH DATA PERTANIAN
              </h1>
            </div>
            <div class="row row-cards">
              <div class="col-sm-12 col-lg-12">
              </div>
            </div>
            <div class="row row-cards row-deck">
            
              <!-- Data Keluarga Awal -->
              <?php
              $rs2 = mysqli_fetch_array(mysqli_query($koneksi,"select * from data_keluarga where kk_nomor='$kkid'"));
              $listrik = "0";
              $daya    = "0";
              $masak   = "0";
              $air     = "0";
              $mck     = "0";
              $bangunan= "0";
              $kons    = "0";
              $rumah   = "0";
              ?>
              
              <div class="col-12">
                  <form action="anggota_kk_tani_simpan.php" method="POST">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><strong>Data Pertanian</strong></td>
                            </tr>
                            <tr>
                              <td colspan="3">Jangka Tanam</td>
                              <td colspan="3">
                                  <select class="form-control" name="tani_jangka" id="tani_jangka">
                                      <option value="0" <?php if($listrik=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($listrik=="1"){ echo "selected"; } ?>>Jangka Panjang</option>
                                      <option value="2" <?php if($listrik=="2"){ echo "selected"; } ?>>Jangka Pendek ( Musiman )</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Jenis Tanaman</td>
                              <td colspan="3">
                                  <input type="text" class="form-control" placeholder="Jenis Tanaman"  name="tani_jenis" id="tani_jenis">
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Luas Lahan (Ha)</td>
                              <td colspan="3">
                                  <input type="text" class="form-control" placeholder="Luas Lahan" name="tani_luas" id="tani_luas">
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Tegakan (Batang)</td>
                              <td colspan="3">
                                  <input type="text" class="form-control" placeholder="Tegakan" name="tani_tegak" id="tani_tegak">
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Umur Tanaman</td>
                              <td colspan="3">
                                  <input type="text" class="form-control" placeholder="Umur Tanaman" name="tani_umur" id="tani_umur">
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Produktivitas (Ton/Ha)</td>
                              <td colspan="3">
                                  <input type="text" class="form-control" placeholder="Produktivitas" name="tani_produk" id="tani_produk">
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Sistem Budidaya</td>
                              <td colspan="3">
                                  <select class="form-control" name="tani_sistem" id="tani_sistem">
                                      <option value="0" <?php if($mck=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($mck=="1"){ echo "selected"; } ?>>Organik</option>
                                      <option value="2" <?php if($mck=="2"){ echo "selected"; } ?>>Semi Organik</option>
                                      <option value="3" <?php if($mck=="3"){ echo "selected"; } ?>>Kimia</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Pemanfaatan Hasil</td>
                              <td colspan="3">
                                  <select class="form-control" name="tani_hasil" id="tani_hasil">
                                      <option value="0" <?php if($kons=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($kons=="1"){ echo "selected"; } ?>>Konsumsi Sendiri</option>
                                      <option value="2" <?php if($kons=="2"){ echo "selected"; } ?>>Konsumsi Sendiri dan Jual</option>
                                      <option value="3" <?php if($kons=="3"){ echo "selected"; } ?>>Jual</option>
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <td colspan="3">Kepemilikan Lahan</td>
                              <td colspan="3">
                                  <select class="form-control" name="tani_milik" id="tani_milik">
                                      <option value="0" <?php if($rumah=="0"){ echo "selected"; } ?>>-</option>
                                      <option value="1" <?php if($rumah=="1"){ echo "selected"; } ?>>Milik Pribadi</option>
                                      <option value="2" <?php if($rumah=="2"){ echo "selected"; } ?>>Sewa</option>
                                      <option value="3" <?php if($rumah=="3"){ echo "selected"; } ?>>Bagi Hasil</option></option>
                                      <option value="4" <?php if($rumah=="4"){ echo "selected"; } ?>>Numpang</option>
                                  </select>
                                  <input type="hidden" name="tani_id" id="tani_id" value="<?php echo base64_encode($kkid); ?>">
                              </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              <!-- Area Submit -->
              <div class="col-12">
                  <div class="card">
                      <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter card-table">
                          <tbody>
                            <tr>
                              <td colspan="6"><input type="submit" class="btn btn-success" value="TAMBAH DATA">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="anggota_kk.php" style="text-decoration:none;">Kembali</a></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              </form>
              <!-- Area Submit -->
              
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
              <div class="row align-items-center">
                <div class="col-auto">
                  <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="./docs/index.php">Documentation</a></li>
                    <li class="list-inline-item"><a href="./faq.html">FAQ</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright © <?php echo date('Y'); ?> <a href=".">SiPeta</a>. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  </body>
</html>
