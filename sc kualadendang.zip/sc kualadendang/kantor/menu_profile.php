<a class="dropdown-item" href="profile.php">
  <i class="dropdown-icon fe fe-user"></i> Profile
</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item" href="logout.php">
  <i class="dropdown-icon fe fe-log-out"></i> Sign out
</a>
