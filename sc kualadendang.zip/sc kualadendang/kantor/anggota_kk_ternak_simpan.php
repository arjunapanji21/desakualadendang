<?php include('tunnel.php'); 

$padi_id = base64_decode($_POST['ternak_id']);
$padi_jn = $_POST['ternak_jenis'];
$padi_vr = $_POST['ternak_jumlah'];
$padi_sb = $_POST['ternak_milik'];
$padi_ls = $_POST['ternak_pelihara'];


$sql="INSERT INTO `data_ternak`(`ternak_autoid`, `kk_nomor`, `ternak_jenis`, `ternak_jumlah`, `ternak_milik`, `ternak_tempat`) 
VALUES (NULL,'$padi_id','$padi_jn','$padi_vr','$padi_sb','$padi_ls')";

mysqli_query($koneksi,$sql);

?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo base64_encode($padi_id); ?>"</script>