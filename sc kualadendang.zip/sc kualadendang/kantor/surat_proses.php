<?php

include('tunnel.php');

$sur_uid      = md5(microtime());
$sur_tanggal  = $_POST['surat_tanggal'];
$sur_nomor    = $_POST['surat_nomor'];
$sur_jenis    = $_POST['surat_jenis'];
$sur_instansi = $_POST['surat_instansi'];
$sur_tebusan  = $_POST['surat_tebusan'];
$sur_judul    = $_POST['surat_judul'];
$sur_ket      = $_POST['surat_keterangan'];

$sql = "INSERT INTO surat (sur_id, sur_uid, sur_nosurat, sur_instansi, sur_kat, sur_judul, sur_keterangan, sur_user, sur_tebusan, sur_buat, sur_terima)
VALUES (NULL, '$sur_uid','$sur_nomor','$sur_instansi','$sur_jenis','$sur_judul','$sur_ket','$userid','$sur_tebusan','$sur_tanggal','$sur_tanggal');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="surat.php";</script>
