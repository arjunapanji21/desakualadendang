<?php
include('../tunnel.php');
?>
<div class="card-table row">
  <div class="col-4">
      <br>
      <div class="col-6 col-sm-4 col-md-2 col-xl mb-3">
        <a href="#" class="btn btn-primary btn-square w-100">
          Pekerjaan
        </a>
      </div>
      <br>
  </div>    
  
  <div class="col-8">
        <center><h2>Buat Data Pekerjaan</h2></center>
        <br>
          <div class="row">
            <div class="col-10">
              <form action="pengaturan1_simpan.php" method="POST">
                <label for="nama_job">Nama Pekerjaan</label>
                <input class="form-control" name="nama_job" id="nama_job" placeholder="Nama Pekerjaan" autocomplete="off" required><br>
                <input type="submit" class="btn btn-success" value="SIMPAN">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="pengaturan.php" style="text-decoration:none;">Kembali</a>
              </form>
              <br><br><br><br><br>
            </div>
          </div>
  </div>



</div>
