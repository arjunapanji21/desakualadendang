<?php
include('../tunnel.php');
?>
<div class="card-table row">
  <div class="col-4">
      <br>
      <div class="col-6 col-sm-4 col-md-2 col-xl mb-3">
        <a href="#" class="btn btn-primary btn-square w-100">
          Pekerjaan
        </a>
      </div>
      <br>
  </div>    
  
  <div class="col-8">
    <div class="card">
        <center><h2>Data Pekerjaan</h2></center>
        <br>
        <div class="row">
          <div class="col-12">
            <a href="pengaturan1_new.php" class="btn btn-sm btn-success">Buat Pekerjaan Baru</a>&nbsp;&nbsp;
            <br><br>
          </div>
        </div>
        
        <table class="table table-vcenter card-table" border="1">
            <thead>
                <tr>
                    <th width="5%">Nomor</th>
                    <th>Nama Pekerjaan</th>
                    <th width="20%">Aksi</th>
                </tr>
            </thead>
            <tbody>
              <?php
              $i=1;
              $query = mysqli_query($koneksi,"select * from pekerjaan order by job_nama ASC");
              while($rs=mysqli_fetch_array($query)){
              ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $rs['job_nama']; ?></td>
                    <td>
                      <a href="pengaturan1_edit.php?id=<?php echo $rs['job_id']; ?>" class="btn btn-sm btn-warning">Edit</a>&nbsp;&nbsp;
                      <a href="pengaturan1_hapus.php?id=<?php echo $rs['job_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Anda yakin menghapus pekerjaan <?php echo $rs['job_nama'] ?> ?\nJika ada data terkait maka akan bermasalah.')">Hapus</a>&nbsp;&nbsp;
                    </td>
                </tr>
              <?php $i+=1;  } ?>
            </tbody>
            
            
        </table>
    </div>
  </div>



</div>
