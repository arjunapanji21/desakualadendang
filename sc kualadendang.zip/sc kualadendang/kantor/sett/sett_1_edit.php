<?php
include('../tunnel.php');
$job_id     = $_GET['id'];
if(!isset($_GET['id'])){
    ?>
    <script>window.location.href="pengaturan.php"</script>
    <?php
}
?>
<div class="card-table row">
  <div class="col-4">
      <br>
      <div class="col-6 col-sm-4 col-md-2 col-xl mb-3">
        <a href="#" class="btn btn-primary btn-square w-100">
          Pekerjaan
        </a>
      </div>
      <br>
  </div>    
  
  <div class="col-8">
        <center><h2>Edit Data Pekerjaan</h2></center>
        <?php
        $rs=mysqli_fetch_array(mysqli_query($koneksi,"select * from pekerjaan where job_id='$job_id'"));
        ?>
        <br>
          <div class="row">
            <div class="col-10">
              <form action="pengaturan1_update.php?id=<?php echo $job_id; ?>" method="POST">
                <label for="nama_job">Nama Pekerjaan</label>
                <input class="form-control" name="nama_job" id="nama_job" placeholder="Nama Pekerjaan" value="<?php echo $rs['job_nama']; ?>" autocomplete="off" required><br>
                <input type="submit" class="btn btn-success" value="PERBAHARUI">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="pengaturan.php" style="text-decoration:none;">Kembali</a>
              </form>
              <br><br><br><br><br>
            </div>
          </div>
  </div>



</div>
