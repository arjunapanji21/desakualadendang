<?php
include('tunnel.php');
$id = base64_decode($_GET['id']);
$kkid=$_GET['uiz'];


mysqli_query($koneksi,"DELETE FROM `data_padi` WHERE padi_autoid='$id'");
?>
<script>window.location.href="anggota_kk_edit.php?kkid=<?php echo $kkid; ?>";</script>