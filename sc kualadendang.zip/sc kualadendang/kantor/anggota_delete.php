<?php

include('tunnel.php');

$anggota_uid      = $_GET['uid'];

$sql = "DELETE FROM anggota where ang_uid='$anggota_uid'";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="anggota.php";</script>
