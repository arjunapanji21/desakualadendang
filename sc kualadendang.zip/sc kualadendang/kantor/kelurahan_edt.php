<?php

include('tunnel.php');

$kel_uid      = $_POST['kel_uid'];
$kel_nama     = $_POST['kel_nama'];
$kec_id       = $_POST['kec_id'];

$sql = "UPDATE kelurahan set kel_nama='$kel_nama', kec_id='$kec_id' where kel_uid='$kel_uid'";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kelurahan.php";</script>
