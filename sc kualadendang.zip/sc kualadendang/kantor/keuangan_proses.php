<?php

include('tunnel.php');

$trans_uid      = md5(microtime());
$trans_tanggal  = $_POST['keu_tanggal'];
$trans_nomor    = $_POST['keu_nota'];
$trans_stat     = $_POST['keu_jenis'];
$trans_instansi = $_POST['keu_instansi'];
$trans_nominal  = $_POST['keu_nominal'];
$trans_ket      = $_POST['keu_keterangan'];
$trans_catatan  = $_POST['keu_catatan'];

$sql = "INSERT INTO transaksi (trans_id, trans_uid, trans_date, trans_post, trans_nonota, trans_stat, trans_instansi, trans_keterangan, trans_catatan, trans_user, trans_nominal)
VALUES (NULL, '$trans_uid','$trans_tanggal','Y','$trans_nomor','$trans_stat','$trans_instansi','$trans_ket','$trans_catatan','$userid','$trans_nominal');";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="keuangan.php";</script>
