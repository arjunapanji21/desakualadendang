<?php
include('../tunnel.php');
$sql = "select * from pekerjaan"; 
$sql2= "select * from anggota where ang_job=''";
$sql3= "select * from anggota where ang_job='";

$query = mysqli_query($koneksi,$sql);


      $var ="";
      $vars=0;
      $i=1;
      while($rs=mysqli_fetch_array($query)){
          if($i==1){
              $var = $rs[1];
              $nilai = $rs[0];
              $sqls = $sql3.$nilai."'";
              $rsj = mysqli_num_rows(mysqli_query($koneksi,$sqls));
              $vars = $rsj;
          }else{
              $var = $var.",".$rs[1];
              $nilai = $rs[0];
              $sqls = $sql3.$nilai."'";
              $rsj = mysqli_num_rows(mysqli_query($koneksi,$sqls));
              $vars = $vars.",".$rsj;
          }
          $i+=1;
      }
      
?>
<?php echo $var; ?><br><?php echo $vars; ?>