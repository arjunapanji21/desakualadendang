<?php
$sql = "select * from pekerjaan"; 
$sql2= "select * from anggota where ang_job=''";


?>

<script>
    var options = {
    chart: {
      type: 'bar'
    },
    series: [{
      name: 'Jumlah',
      <?php 
      $var ="";
      while($rs=mysqli_fetch_array($sql)){
          $var =$rs[1];
      }
      ?>
      data: [<?php echo $var; ?>,<?php echo $perempuan; ?>,<?php echo $nojenkel; ?>]
    }],
    xaxis: {
      categories: [<?php echo $var; ?>,'Tidak Mengisi']
    }
  }

  var chart = new ApexCharts(document.querySelector("#chart"), options);

  chart.render();
</script>
<?php echo $var; ?> A