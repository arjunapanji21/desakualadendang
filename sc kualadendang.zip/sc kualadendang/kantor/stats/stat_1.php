<?php
                $laki2 = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_sex='1'"));
                $perempuan= mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_sex='2'"));
                $nojenkel = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota"));
                $nojenkel = $nojenkel - $laki2 - $perempuan;
                $bekerja = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_job!='11'"));
                $tbekerja= mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_job='11'"));
                ?>
                <div class="card-table row">
                  <div class="col-4">
                      <br>
                      <div class="col-6 col-sm-4 col-md-2 col-xl mb-3">
                        <a href="#" class="btn btn-primary btn-square w-100">
                          Jenis Kelamin
                        </a>
                      </div>
                      <div class="col-6 col-sm-4 col-md-2 col-xl mb-3">
                        <a href="statistik.php?menus=bekerja" class="btn btn-light btn-square w-100">
                          Bekerja
                        </a>
                      </div>
                      <div class="col-6 col-sm-4 col-md-2 col-xl mb-3">
                        <a href="statistik.php?menus=sekolah" class="btn btn-light btn-square w-100">
                          Pendidikan
                        </a>
                      </div>
                      <br>
                  </div>    
                  
                  <div class="col-8">
                    <div class="card">
                        <center><h2>Data Jenis Kelamin</h2></center>
                        <div id="chart" style="min-width: 100%;"></div><hr>
                        <table class="table table-vcenter card-table" border="1">
                            <thead>
                                <tr>
                                    <th>Jenis Kelompok</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Laki - Laki</td>
                                    <td><?php echo $laki2; ?> Orang</td>
                                </tr>
                                <tr>
                                    <td>Perempuan</td>
                                    <td><?php echo $perempuan; ?> Orang</td>
                                </tr>
                                <tr>
                                    <td>Tidak Mengisi</td>
                                    <td><?php echo $nojenkel; ?> Orang</td>
                                </tr>
                                <tr>
                                    <td>Total</td>
                                    <td><?php echo $nojenkel+$laki2+$perempuan; ?> Orang</td>
                                </tr>
                            </tbody>
                            
                            
                        </table>
                    </div>
                  </div>

               

              </div>
              <?php
                include('../tunnel.php');
                $sql = "select * from statuskelamin"; $sql2= "select * from anggota where ang_sex=''"; $sql3= "select * from anggota where ang_sex='";
                
                
                    $query = mysqli_query($koneksi,$sql);
                    
                          $var ="";
                          $vars=0;
                          $jml =0;
                          $i=1;
                          while($rs=mysqli_fetch_array($query)){
                              if($i==1){
                                  $var = "'".$rs[1]."'";
                                  $nilai = $rs[0];
                                  $sqls = $sql3.$nilai."'";
                                  $rsj = mysqli_num_rows(mysqli_query($koneksi,$sqls));
                                  $vars = $rsj;
                              }else{
                                  $var = $var.",'".$rs[1]."'";
                                  $nilai = $rs[0];
                                  $sqls = $sql3.$nilai."'";
                                  $rsj = mysqli_num_rows(mysqli_query($koneksi,$sqls));
                                  $vars = $vars.",".$rsj;
                              }
                              $i+=1;
                          }
                    ?>
                    <script>
                        var options = {
                        chart: {
                          type: 'bar',
                          width: '100%'
                        },
                        series: [{
                          name: 'Jumlah',
                          data: [<?php echo $vars; ?>,0]
                        }],
                        xaxis: {
                          categories: [<?php echo $var; ?>,'Tidak Mengisi']
                        }
                      }
                    
                      var chart = new ApexCharts(document.querySelector("#chart"), options);
                    
                      chart.render();
                    </script>