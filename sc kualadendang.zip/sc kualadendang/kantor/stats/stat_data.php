<?php
include('../tunnel.php');
$data=$_GET['data'];
if($data=="jenkel"){ $sql = "select * from "; }
if($data=="bekerja"){ $sql = "select * from pekerjaan"; $sql2= "select * from anggota where ang_job=''"; $sql3= "select * from anggota where ang_job='"; }


    $query = mysqli_query($koneksi,$sql);
    
          $var ="";
          $vars=0;
          $jml =0;
          $i=1;
          while($rs=mysqli_fetch_array($query)){
              if($i==1){
                  $var = "'".$rs[1]."'";
                  $nilai = $rs[0];
                  $sqls = $sql3.$nilai."'";
                  $rsj = mysqli_num_rows(mysqli_query($koneksi,$sqls));
                  $vars = $rsj;
              }else{
                  $var = $var.",'".$rs[1]."'";
                  $nilai = $rs[0];
                  $sqls = $sql3.$nilai."'";
                  $rsj = mysqli_num_rows(mysqli_query($koneksi,$sqls));
                  $vars = $vars.",".$rsj;
              }
              $i+=1;
          }
    ?>
    <script>
        var options = {
        chart: {
          type: 'bar'
        },
        series: [{
          name: 'Jumlah',
          data: [<?php echo $vars; ?>,0]
        }],
        xaxis: {
          categories: [<?php echo $var; ?>,'Tidak Mengisi']
        }
      }
    
      var chart = new ApexCharts(document.querySelector("#chart"), options);
    
      chart.render();
    </script>