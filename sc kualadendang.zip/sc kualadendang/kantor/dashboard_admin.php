<div class="page">
      <div class="page-main">
        <div class="header py-4">
          <div class="container">
            <div class="d-flex">
              <a class="header-brand" href="./index.php">
                <img src="./assets/images/logo/pramuka.png" class="header-brand-img" alt="tabler logo"> SiPETA
              </a>
              <div class="d-flex order-lg-2 ml-auto">
                <div class="dropdown">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(./demo/faces/female/25.jpg)"></span>
                    <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo $user; ?></span>
                      <small class="text-muted d-block mt-1"><?php echo $usergugus; ?></small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                    <?php include('menu_profile.php'); ?>
                  </div>
                </div>
              </div>
              <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="./index.php" class="nav-link active"><i class="fe fe-home"></i> Home</a>
                  </li>
                  <li class="nav-item">
                    <a href="./info_desa.php" class="nav-link"><i class="fe fe-award"></i> Info Desa</a>
                  </li>
                  <li class="nav-item">
                    <a href="./anggota.php" class="nav-link"><i class="fe fe-users"></i> Penduduk</a>
                  </li>
                  <li class="nav-item">
                    <a href="./statistik.php" class="nav-link"><i class="fe fe-users"></i> Statistik</a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown"><i class="fe fe-box"></i> Sekretariat</a>
                    <div class="dropdown-menu dropdown-menu-arrow">
                      <a href="surat.php" class="dropdown-item ">Layanan Surat</a>
                      <a href="keuangan.php" class="dropdown-item ">Keuangan</a>
                      <a href="#" class="dropdown-item ">Pertanahan</a>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Analisis</a>
                  </li>
                  <li class="nav-item">
                    <a href="pengaturan.php" class="nav-link"><i class="fe fe-settings"></i> Pengaturan</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="nav-link" onclick="window.alert('Menu sedang diproses');"><i class="fe fe-users"></i> Admin Web</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title">
                Dashboard Admin
              </h1>
            </div>
            <!--
            <div class="row row-cards">
              <div class="col-sm-6 col-lg-3">
                <div class="card p-3">
                  <div class="d-flex align-items-center">
                    <span class="stamp stamp-md bg-blue mr-3">
                      <i class="fe fe-dollar-sign"></i>
                    </span>
                    <div>
                      <h4 class="m-0"><a href="javascript:void(0)">132 <small>Pembayaran</small></a></h4>
                      <small class="text-muted">12 belum membayar</small>
                    </div>
                  </div>
                </div>
              </div>
              <?php $jumlahpembina=mysqli_num_rows(mysqli_query($koneksi,"select ang_uid from anggota where ang_level='2'")); ?>
              <?php $jumlahinstans=mysqli_num_rows(mysqli_query($koneksi,"select ins_uid from instansi")); ?>
              <div class="col-sm-6 col-lg-3">
                <div class="card p-3">
                  <div class="d-flex align-items-center">
                    <span class="stamp stamp-md bg-green mr-3">
                      <i class="fe fe-user"></i>
                    </span>
                    <div>
                      <h4 class="m-0"><a href="javascript:void(0)"><?php echo $jumlahpembina ?> <small>Total Pembina</small></a></h4>
                      <small class="text-muted"><?php echo $jumlahinstans ?> Total Instansi</small>
                    </div>
                  </div>
                </div>
              </div>
              <?php $bulan = date('m'); ?>
              <?php $jumlahanggota=mysqli_num_rows(mysqli_query($koneksi,"select ang_uid from anggota")); ?>
              <?php $jumlahangulta=mysqli_num_rows(mysqli_query($koneksi,"select ang_uid from anggota where month(ang_tanggallahir) = '$bulan'")); ?>
              <div class="col-sm-6 col-lg-3">
                <div class="card p-3">
                  <div class="d-flex align-items-center">
                    <span class="stamp stamp-md bg-red mr-3">
                      <i class="fe fe-users"></i>
                    </span>
                    <div>
                      <h4 class="m-0"><a href="javascript:void(0)"><?php echo $jumlahanggota ?> <small>Total Anggota</small></a></h4>
                      <small class="text-muted"><?php echo $jumlahangulta ?> Anggota ultah bulan ini</small>
                    </div>
                  </div>
                </div>
              </div>
              <?php $jumlahkegiatan=mysqli_num_rows(mysqli_query($koneksi,"select keg_uid from kegiatan")); ?>
              <?php $jumlahkegbelom=mysqli_num_rows(mysqli_query($koneksi,"select keg_uid from kegiatan where keg_dateend >= '$today'")); ?>
              <div class="col-sm-6 col-lg-3">
                <div class="card p-3">
                  <div class="d-flex align-items-center">
                    <span class="stamp stamp-md bg-yellow mr-3">
                      <i class="fe fe-activity"></i>
                    </span>
                    <div>
                      <h4 class="m-0"><a href="javascript:void(0)"><?php echo $jumlahkegiatan; ?> <small>Total Kegiatan</small></a></h4>
                      <small class="text-muted"><?php echo $jumlahkegbelom; ?> belum selesai</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            -->
            <div class="row row-cards row-deck">
              <div class="col-lg-6">
                <div class="card card-aside">
                  <div class="card-body d-flex flex-column">
                    <h4>PAPAN PENGUMUMAN 1 DESA</h4>
                    <div class="text-muted"><?php echo $rsdatapeta['conf_pesan1']; ?></div>
                    <div class="d-flex align-items-center pt-5 mt-auto">
                      <div>
                        <small class="d-block text-muted"><?php echo dtostr($rsdatapeta['conf_pesan1date']); ?></small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="card card-aside">
                  <div class="card-body d-flex flex-column">
                    <h4>PAPAN PENGUMUMAN 2 DESA</h4>
                    <div class="text-muted"><?php echo $rsdatapeta['conf_pesan2']; ?></div>
                    <div class="d-flex align-items-center pt-5 mt-auto">
                      <div>
                        <small class="d-block text-muted"><?php echo dtostr($rsdatapeta['conf_pesan2date']); ?></small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="row row-cards row-deck">
              <!--
              <div class="col-12">
                <div class="card">
                  <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                      <thead>
                        <tr>
                          <th colspan="7"><center>INFO KEGIATAN INSTANSI TERAKTIF BULAN INI</center></th>
                        </tr>
                        <tr>
                          <th class="text-center w-1"><i class="icon-people"></i></th>
                          <th>INSTANSI</th>
                          <th>KEGIATAN BULAN INI ( <?php echo dtotext($today); ?> <?php echo date('Y'); ?> )</th>
                          <th>JUMLAH ANGGOTA</th>
                          <th class="text-center">KEAKTIFAN</th>
                          <th class="text-center"><i class="icon-settings"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td class="text-center">
                            <div class="avatar d-block" style="background-image: url(demo/faces/female/26.jpg)">
                              <span class="avatar-status bg-green"></span>
                            </div>
                          </td>
                          <td>
                            <div>SMPN 1 JAMBI</div>
                            <div class="small text-muted">
                              Pendaftaran : 25 November 2020
                            </div>
                          </td>
                          <td>
                              5 Kegiatan
                          </td>
                          <td>
                            <div>500 Orang</div>
                          </td>
                          <td class="text-center">
                            <div class="mx-auto chart-circle chart-circle-xs" data-value="0.42" data-thickness="3" data-color="blue">
                              <div class="chart-circle-value">42%</div>
                            </div>
                          </td>
                          <td class="text-center">
                            <div class="item-action dropdown">
                              <a href="javascript:void(0)" data-toggle="dropdown" class="icon"><i class="fe fe-more-vertical"></i></a>
                              <div class="dropdown-menu dropdown-menu-right">
                                <a href="javascript:void(0)" class="dropdown-item"><i class="dropdown-icon fe fe-tag"></i> Action </a>
                                <a href="javascript:void(0)" class="dropdown-item"><i class="dropdown-icon fe fe-edit-2"></i> Another action </a>
                                <a href="javascript:void(0)" class="dropdown-item"><i class="dropdown-icon fe fe-message-square"></i> Something else here</a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0)" class="dropdown-item"><i class="dropdown-icon fe fe-link"></i> Separated link</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              -->
              <div class="col-md-6 col-lg-4">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Statistik Desa Gurun Tuo</h3>
                  </div>
                  <div class="card-body o-auto" style="height: 15rem">
                    <ul class="list-unstyled list-separated">
                      <li class="list-separated-item">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <span class="avatar avatar-md d-block" style="background-image: url(assets/images/logo/pramuka.png)"></span>
                          </div>
                          <div class="col">
                            <div>
                              <a href="javascript:void(0)" class="text-inherit">Penduduk</a>
                            </div>
                          </div>
                          <?php $jumlahpenduduk = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_aktif='1'")); ?>
                          <div class="col-auto">
                            <?php echo $jumlahpenduduk; ?> Orang
                          </div>
                        </div>
                      </li>
                      <li class="list-separated-item">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <span class="avatar avatar-md d-block" style="background-image: url(assets/images/logo/pramuka.png)"></span>
                          </div>
                          <div class="col">
                            <div>
                              <a href="javascript:void(0)" class="text-inherit">Bekerja</a>
                            </div>
                          </div>
                          <?php $jumlahebekerja = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_job!='11' and ang_aktif='1'")); ?>
                          <div class="col-auto">
                            <?php echo $jumlahebekerja; ?> Orang
                          </div>
                        </div>
                      </li>
                      <li class="list-separated-item">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <span class="avatar avatar-md d-block" style="background-image: url(assets/images/logo/pramuka.png)"></span>
                          </div>
                          <div class="col">
                            <div>
                              <a href="javascript:void(0)" class="text-inherit">Tidak Bekerja</a>
                            </div>
                          </div>
                          <?php $jumlahtidakbekerja = mysqli_num_rows(mysqli_query($koneksi,"select * from anggota where ang_job='11' and ang_aktif='1'")); ?>
                          <div class="col-auto">
                            <?php echo $jumlahtidakbekerja; ?> Orang
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-6 col-lg-4">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Kegiatan Berjalan Bulan Ini</h3>
                  </div>
                  <div class="card-body o-auto" style="height: 15rem">
                    <ul class="list-unstyled list-separated">
                      <?php
                      $query_kegiatan = mysqli_query($koneksi,"select * from kegiatan order by keg_id DESC limit 3");
                      while($rs_kegiatan=mysqli_fetch_array($query_kegiatan)){

                        $instansi = $rs_kegiatan['2'];

                        $rs_instansi = mysqli_fetch_array(mysqli_query($koneksi,"select ins_nama from instansi where ins_uid ='$instansi'"));
                        $ins_nama = $rs_instansi['ins_nama'];

                      ?>
                      <li class="list-separated-item">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <span class="avatar avatar-md d-block" style="background-image: url(assets/images/logo/pramuka.png)"></span>
                          </div>
                          <div class="col">
                            <div>
                              <a href="javascript:void(0)" class="text-inherit"><?php echo $rs_kegiatan['5']; ?><br><?php echo dtostr($rs_kegiatan['3']); ?></a>
                            </div>
                            <small class="d-block item-except text-sm text-muted h-1x"><?php echo $usergugus; ?></small>
                          </div>
                        </div>
                      </li>
                      <?php } ?>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-6 col-lg-4">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Penduduk Terbaru</h3>
                  </div>
                  <div class="card-body o-auto" style="height: 15rem">
                    <ul class="list-unstyled list-separated">
                      <?php
                      $query_orang = mysqli_query($koneksi,"select * from anggota order by ang_id DESC limit 3");
                      while($rs_orang=mysqli_fetch_array($query_orang)){
                      ?>
                      <li class="list-separated-item">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <span class="avatar avatar-md d-block" style="background-image: url(demo/faces/female/12.jpg)"></span>
                          </div>
                          <div class="col">
                            <div>
                              <a href="javascript:void(0)" class="text-inherit"><?php echo $rs_orang['4']; ?></a>
                            </div>
                            <small class="d-block item-except text-sm text-muted h-1x"><?php echo $rs_orang['8']; ?></small>
                          </div>
                        </div>
                      </li>
                      <?php } ?>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
              <div class="row align-items-center">
                <div class="col-auto">
                  <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="./docs/index.php">Documentation</a></li>
                    <li class="list-inline-item"><a href="./faq.html">FAQ</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
              Copyright © <?php echo date('Y'); ?> <a href=".">SiPeta</a>. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>