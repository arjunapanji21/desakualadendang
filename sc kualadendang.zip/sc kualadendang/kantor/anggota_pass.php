<?php

include('tunnel.php');

$anggota_uid      = $_GET['uid'];
$anggota_password = sha1("12345");

$sql = "UPDATE anggota set ang_password='$anggota_password' where ang_uid='$anggota_uid'";

//echo $sql;
mysqli_query($koneksi,$sql);
?>
<script>window.location.href="anggota.php";</script>
