<?php

include('tunnel.php');

$kel_uid      = $_GET['uid'];

$sql = "DELETE FROM kelurahan where kel_uid='$kel_uid';";
//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="kelurahan.php";</script>
