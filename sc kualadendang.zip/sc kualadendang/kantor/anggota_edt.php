<?php

include('tunnel.php');

$anggota_uid      = $_POST['uid'];
$anggota_kk       = $_POST['anggota_kk'];
$anggota_nomor    = $_POST['anggota_nomor'];
$anggota_nama     = ucwords(strtolower($_POST['anggota_nama']));
$anggota_tempat   = $_POST['anggota_tempat'];
$anggota_tanggal  = $_POST['anggota_tanggal'];
$anggota_email    = $_POST['anggota_email'];
$anggota_hp       = $_POST['anggota_hp'];
$anggota_gugus    = $_POST['anggota_gugus'];
$anggota_add      = $_POST['anggota_add'];
$anggota_x        = $_POST['anggota_x'];
$anggota_y        = $_POST['anggota_y'];
$anggota_job      = $_POST['anggota_job'];
$anggota_password = sha1("12345");

// New Form Update 9 Agustus 2021 //
$anggota_jk       = $_POST['anggota_jk'];//
$anggota_ektp     = $_POST['anggota_ektp'];//
$anggota_agama    = $_POST['anggota_agama'];//
$anggota_sttspend = $_POST['anggota_statuspenduduk'];

$anggota_noakta   = $_POST['anggota_nomorakta'];
$anggota_wktlhr   = $_POST['anggota_waktulahir'];
$anggota_lkslhr   = $_POST['anggota_lokasilahir'];
$anggota_jnslhr   = $_POST['anggota_jenislahir'];

$anggota_anakke   = $_POST['anggota_anakke'];
$anggota_pnlglhr  = $_POST['anggota_penolonglahir'];
$anggota_beratlhr = $_POST['anggota_beratlahir'];
$anggota_pjglahir = $_POST['anggota_panjanglahir'];

$anggota_pddkkk   = $_POST['anggota_pendidikankk'];
$anggota_pddkjln  = $_POST['anggota_pendidikanberjalan'];

$anggota_wn       = $_POST['anggota_warganegara'];
$anggota_nopaspor = $_POST['anggota_nopaspor'];
$anggota_tglpaspor= $_POST['anggota_tglpaspor'];
$anggota_nokitas  = $_POST['anggota_nokitas'];

$anggota_ktpayah  = $_POST['anggota_ktpayah'];
$anggota_noktpayah= ucwords(strtolower($_POST['anggota_namaayah']));
$anggota_ktpibu   = $_POST['anggota_ktpibu'];
$anggota_noktpibu = ucwords(strtolower($_POST['anggota_namaibu']));

$anggota_sttskawin= $_POST['anggota_statuskawin'];
$anggota_noaktakwn= $_POST['anggota_noaktanikah'];
$anggota_tglkwn   = $_POST['anggota_tglnikan'];
$anggota_noaktacri= $_POST['anggota_noaktacerai'];
$anggota_tglcri   = $_POST['anggota_tglcerai'];

$anggota_goldarah = $_POST['anggota_golongandarah'];

$anggota_ketcacat = $_POST['anggota_ketcacat'];
$anggota_ketsakit = $_POST['anggota_ketsakit'];
$anggota_akskb    = $_POST['anggota_akskb'];
$anggota_asuransi = $_POST['anggota_statusasuransi'];

$anggota_pdptbln  = $_POST['anggota_pendapatanbulan'];
$anggota_pdptmusim= $_POST['anggota_pendapatanmusim'];


$sql = "UPDATE anggota set ang_kk='$anggota_kk',ang_nomor='$anggota_nomor', ang_nama='$anggota_nama', ang_tempatlahir='$anggota_tempat', ang_tanggallahir='$anggota_tanggal', ang_email='$anggota_email', ang_notelpon='$anggota_hp', ang_instansi='$anggota_gugus',ang_x='$anggota_x',ang_y='$anggota_y',ang_job='$anggota_job',ang_alamat='$anggota_add',ang_sex='$anggota_jk',ang_ektp='$anggota_nomor',ang_ektprek='$anggota_ektp',ang_agama='$anggota_agama',ang_statuspenduduk='$anggota_sttspend',ang_aktano='$anggota_noakta',ang_waktulahir='$anggota_wktlhr',ang_lokasilahir='$anggota_lkslhr',ang_jenislahir='$anggota_jnslhr',ang_anakke='$anggota_anakke',ang_penolong='$anggota_pnlglhr',ang_beratlahir='$anggota_beratlhr',ang_panjanglahir='$anggota_pjglahir',ang_pendidikankk='$anggota_pddkkk',ang_pendidikannow='$anggota_pddkjln',ang_warganegara='$anggota_wn',ang_pasporno='$anggota_nopaspor',ang_pasportgl='$anggota_tglpaspor',ang_kitasno='$anggota_nokitas',ang_ayahnik='$anggota_ktpayah',ang_ayahnama='$anggota_noktpayah',ang_ibunik='$anggota_ktpibu',ang_ibunama='$anggota_noktpibu',ang_statuskawin='$anggota_sttskawin',ang_nikahno='$anggota_noaktakwn',ang_nikahtanggal='$anggota_tglkwn',ang_ceraino='$anggota_noaktacri',ang_ceraitanggal='$anggota_tglcri',ang_goldarah='$anggota_goldarah',ang_cacatpermanen='$anggota_ketcacat',ang_sakitmenahun='$anggota_ketsakit',ang_akseptorkb='$anggota_akskb',ang_asuransi='$anggota_asuransi',ang_pendapatanbulan='$anggota_pdptbln',ang_pendapatmusim='$anggota_pdptmusim' where ang_uid='$anggota_uid'";

//echo $sql;

mysqli_query($koneksi,$sql);
?>
<script>window.location.href="anggota_edit.php?uid=<?php echo $anggota_uid; ?>";</script>
